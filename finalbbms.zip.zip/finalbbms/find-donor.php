<?php 
//session_start();
$db = mysqli_connect('localhost','root','','bbms');
//if($_SESSION['user'] == true)
//{
  //  $id= $_SESSION['user'];
 // $_SESSION['success'] = "You are now logged in";
  //echo"<script>alert('you are logged in')</script>";
 // ?>
<form class="findform" autocomplete="off" action="#" method="post">
<label class="l1"><b>select blood group :</b></label>
	<select name="choose" class="choose" required>
	<option value="choose"><i>choose blood group<i></option>
	<option value="A+">A+</option>
	<option value="A-">A-</option>
	<option value="B+">B+</option>
	<option value="B-">B-</option>
	<option value="AB+">AB+</option>
	<option value="AB-">AB-</option>
	<option value="O+">O+</option>
	<option value="O-">O-</option>
	</select>
	<input type="submit" name="sub" value="Find" class="btn1"><br>
	<?php
	if(isset($_POST['sub'])){
		$group = $_POST['choose'];
		if($group != 'choose'){

  $s1 = "SELECT d1.`DID`,Fname,Lname,blood_type,ph_no,house_no,street,area,city,state,d2.`pincode` FROM `donor` d1,blood,`address` d2,`daddress2` d3 Where blood_type='$group' and d1.`DID`=B_DID and d1.`DID`=d2.`DID` and d2.`pincode`=d3.`pincode` group by DID";
  //$s2 = "SELECT blood_type FROM blood Where blood_type='$group' and DID=B_DID";
  $rs1 = mysqli_query($db,$s1);
  if(mysqli_num_rows($rs1)>0){
  	?>
  	</form>
  	<table class="t1" align="left">
  		<tr>
  			<th>Name</th><th>blood group</th><th>phone number</th><th class="add">address</th>
  		</tr>
  	<?php
  	while($row = mysqli_fetch_array($rs1)){
  		$did = $row['DID'];
  		$fn = $row['Fname'];
  		$ln = $row['Lname'];
  		$group1 = $row['blood_type'];
		$phno = $row['ph_no'];
		$h1 = $row['house_no'];
		$h2 = $row['area'];
		$h3 = $row['street'];
		$h4 = $row['city'];
		$h5 = $row['state'];
		$h6 = $row['pincode'];
  		?>
  		<tr>
  			<td><?php echo $fn." ".$ln; ?></td><td><?php echo $group1; ?></td><td><?php echo $phno; ?></td><td class="add"><?php echo $h1.', '.$h2.', '.$h3.', '.$h4.', '.$h5.' -'.$h6; ?></td>
  		</tr>
  		<?php
  		
  	}
  }
  else{
  	echo "<h4><script>alert(' NO Donor is Currently Active')</script></h4>";
  }
  }
  else 
  	echo "<script>alert('Choose Blood Group')</script>";
}

?>

</table>
<?php 
//}
?>

<style>
	.t1{
		width: 80%;
		text-align: center;
		text-transform: capitalize;
		outline: none;
		border:none;
		border-radius: 0px 20px  0px 20px;
		margin-left: 5%;
		margin-top: 5%;
		margin-bottom: 5%;
	}
	.t1 th{
		width:150px;
		background-color: black;
		padding: 5px;
		color: red;
		font-size: 18px;
		font-family: "rubik";
		border-collapse: collapse;
	}
	.t1 th.add{
		width:40%;
		text-align: center;
	}
	.t1 td{
		background-color: black;
		color: white;
		border:none;
	}
	.t1 td.add{
		text-align: left;
		padding :5px;
	}
	h4{
		text-transform: capitalize;
	}
 	.findform{
 		margin-left: 30px;
 		margin-top: 60px;
 		display: block;
 		border-radius: 20px;
 		width: 470px;
 		padding: 15px;
 		background-color: grey;
 		color: black;
 	}
 	.l1{
 		text-align: right;
 		text-transform: capitalize;
 		padding: 5px;
 		color: white;
 		font-family: "rubik";
 		font-size: 18px;
 	}
 	
 	.choose{
 		padding: 5px;
 		width: 170px;
 		font-size: 14px;
 		text-align: center;
 		outline: none;
 		border: 1px solid black;
 		border-radius: 20px;
 		align-content: right;
 	}
 	.btn1{
 		margin-top: 10px;
 		margin-left: 0px;
 		width: 100px;
 		padding: 5px;
 		text-align: center;
 		font-size: 16px;
 		border:1px solid black;
 		border-radius: 20px;
 		outline: none;
 		
 		background-color: black;
 		font-weight: bold;
 		color: red;
 		text-transform: uppercase;
 		font-style: bold;
 	}
 	
 </style>