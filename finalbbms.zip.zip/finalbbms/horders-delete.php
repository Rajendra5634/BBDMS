<?php 
session_start();
if($_SESSION['hosid'] == true){
    $id= $_SESSION['hosid'];
  $_SESSION['success'] = "You are now logged in";

  $db = mysqli_connect('localhost','root','','bbms');
  error_reporting(0);
    $bid = $_GET['rn'];
      $upq = "SELECT SUM(`A+`+`A-`+`B+`+`B-`+`AB+`+`AB-`+`O+`+`O-`) AS total_orders FROM horders where HID='$id' AND HBBID = '$bid'";
      $rupq = mysqli_query($db,$upq);
      $dq = "DELETE FROM horders WHERE HID='$id' and HBBID='$bid'";
      while($row = mysqli_fetch_array($rupq))
        $delorder = $row['total_orders'];
        $delup = "UPDATE blood_bank SET orders = orders-'$delorder' WHERE BBID = '$bid'";
      $dr = mysqli_query($db,$dq);
      ?>

          
        
      <?php
      if($dr){
        $rdelorder = mysqli_query($db,$delup);
        if($rdelorder){
        echo"<p><script type='text/javascript'> alert('Order Deleted Successfully')</script></p>";
        header('location:hospital-control.php');
      }
    }
      else{
        echo"<p><script type='text/javascript'> alert('Order not Deleted')</script></p>";
        header('location:hospital-control.php');
      }

  				?>
        
          <?php
  		}
  		
         ?>

    <style>
      
      p{
        margin-top: 200px;
        text-transform: uppercase;
        color: green;
        text-align: center;
        font-family: "rubik";
        font-size: 30px;
      }
    </style>