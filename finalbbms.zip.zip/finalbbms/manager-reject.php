<?php 
session_start();
if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";

  $db = mysqli_connect('localhost','root','','bbms');
  error_reporting(0);
    $hid = $_GET['reject'];
     
      $dq1 = "SELECT BBID from blood_bank Where BMID='$id'";
      $Rdq1 = mysqli_query($db,$dq1);
      if(mysqli_num_rows($Rdq1)>0){
        while($row=mysqli_fetch_array($Rdq1))
          $BID = $row['BBID'];

         $delord = "SELECT SUM(`A+`+`A-`+`B+`+`B-`+`AB+`+`AB-`+`O+`+`O-`) AS torders FROM horders WHERE HID = '$hid' AND HBBID = '$BID'";
         $rdelord = mysqli_query($db,$delord);
         //print_r($rdelord);
         if(mysqli_num_rows($rdelord)>0){
          while($row = mysqli_fetch_array($rdelord)){
            $torder = $row['torders'];
            //echo $row['torders'];
             
          }
        }
          $fetch = "UPDATE blood_bank SET orders = orders-'$torder' WHERE BBID = '$BID'";
          $rfetch = mysqli_query($db,$fetch);

          if($rfetch){
         $dq = "DELETE FROM horders WHERE HID='$hid' and HBBID='$BID'";
         $dr = mysqli_query($db,$dq);
      }
      else
        echo "error";
      
      
      ?>

          
        
      <?php
      if(($dr)&&($rfetch))
        echo"<p><script type='text/javascript'> alert('Order Deleted Successfully')</script></p>";

      else
        echo"<p><script type='text/javascript'> alert('Order Not Deleted')</script></p>";
  				?>
        
          <?php
  		}else 
          echo "<script type='text/javascript'> alert('Error')</script>";
    }
  		
         ?>

    <style>
      
      p{
        margin-top: 200px;
        text-transform: uppercase;
        color: green;
        text-align: center;
        font-family: "rubik";
        font-size: 30px;
      }
    </style>