<?php 
//session_start();
$db = mysqli_connect('localhost','root','','bbms');
if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
  }

  $query1= "SELECT * from blood_bank_manager WHERE MID = '$id'";
  $result1 = $db->query($query1);
   if(mysqli_num_rows($result1) > 0){
     //echo "failed to get:".$mysqli->error;
   	 while($row = mysqli_fetch_array($result1)){
?>


<table class="t2" align="center">
	<caption>MANAGER PROFILE</caption>
	
	<tr><th>Manager ID :</th><td><?php echo $row["MID"]; ?></td><br></tr>
     <tr><th>Name :</th><td><?php echo $row["Fname"]."\t".$row["Lname"]; ?></td><br></tr>
        <tr><th>Email :</th><td class="email"><?php echo $row["email"]; ?></td><br></tr>
        <tr><th>Phone no :</th><td><?php echo $row["ph_no"]; ?></td></tr>
</table>
<?php 
}
}
else 
	echo "failed to get:".$mysqli->error;
	 ?>
	


 
 	