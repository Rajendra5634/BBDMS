<?php 

//establishing connection
$db = mysqli_connect('localhost', 'root', '', 'bbms');

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>signup manager</title>
<link href="http://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
<style type="text/css">
  *{
margin: 0;
padding: 0;
box-sizing: border-box;
text-decoration: none;
}
body{
font-family: 'Raleway', sans-serif;
background: url(manager.jpg);
background-repeat: no-repeat;
background-size: cover;
}
.background{
background-image: url(manager.jpg);
background-size: cover;
height: 100vh;
display: flex;
}
.text, .box{
margin-top: 45vh;
}
.text{
margin-top: 20%;
margin-left: 0%;
max-height: 300px;
width: 200px;
}
.box{
margin-top: 11%;
padding-left: 26%;
flex: 1;
}
.text h1{

font-size: 70px;
color: black;
font-weight: 500;

}
.text p{
font-size: 20px;
color: black;
font-weight: 300;
}
.text p a{
color: #fff;
font-weight: 700;
}
.text p a:hover{
  color: red;
}
.form{
background: white;
color: black;
box-sizing: border-box;
display: flex;
flex-direction: column;
width: 350px;
opacity: 0.9;
border-radius: 20px;
padding: 20px;
}
img{
  border-image: white;
  margin: 0px;
  width: 70px;
  height: 60px;
  align-items: center;
}
label{
  margin:10px 5px;
  padding: 0px;
  float: right;
  font-size: 20px;
  font-family: times new roman;
  font-style: bold italic;
  flex-direction: absolute;
  color: black;
}

input{
margin: 10px 0;
padding: 10px;
background: transparent;
border: 1px solid black;
border-radius: 20px;
outline: none;
color: black;
background-color: white;
font-family: 'Raleway', sans-serif;
}
.mid, .username, .email, .password, .phoneno{
border: 2px solid black;
border-radius: 20px;
}
.username, .password{
  width: 130px;
}
::placeholder{
  color:black;
}
.button{
background: black;
border: 2px solid yellow;
border-radius: 20px;
color: #fff;
font-size: 18px;
width: 100px;
}
.button:hover{
background: yellow;
color: black;
}
</style>
</head>
<?php include('header.php'); ?>
<body>
<main>
<div class="background">
<div class="text">
<h1>Register As Manager</h1>
<p><b>Have Account?</b><a href="manager-login.php">Login</a><br>or <br><a href="frontpage.html">Go Back To Home</a></p>
</div>
<div class="box">
<form class="form" autocomplete="off" method="post" action="#">
  <img src="user-logo.png" align="center">
<label>Manager-ID:<br><input type="alphanumeric" name="mid" class="mid" placeholder="Manager-ID"required></label>
<label>Name:<br><input type="text" name="fname" class="username" placeholder="firstname"required>
      <input type="text" name="lname" class="username" placeholder="lastname" required></label>
<label>Email-ID:<br><input type="text" name="email" class="email" placeholder="eg:abc@gmail.com"required></label>
<label>Password:<br><input type="password" name="p1" class="password" placeholder="enter password"required>
      <input type="password" name="p2" class="password" placeholder="confirm password" required></label>
<label>Phone-no:<br><input type="text" name="phno" class="phoneno" placeholder="eg:1234567890"required></label>

<?php 
if(isset($_POST['mid'])){
  $MID = $_POST['mid'];
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $email = $_POST['email'];
  $phno = $_POST['phno'];
  $pass = $_POST['p1'];
  $pass1 = $_POST['p2'];
  //inserting the entered values to database
  if($pass==$pass1){
    $query = "INSERT INTO blood_bank_manager(MID,Fname,Lname,email,password,ph_no) VALUES('$MID','$fname', '$lname', '$email','$pass', '$phno')";
    //mysqli_query($db,$query);
    //mysqli_execute($db,$query);
    if($db->query($query)==true){
    echo"<script type='text/javascript'> alert('Registered Successfully')</script>";
    header('location: manager-login.php');}
   else
    echo"<script type='text/javascript'> alert('Enter Valid ID/Email')</script>";
  
  }
  else
    echo "<script type='text/javascript'> alert('Password Does Not Match')</script>password does not matches";
  }
    $db->close();
 ?>
<input type="submit" name="submit" class="button" value="Signup">
</form>
</div>
</div>
</main>

</body>
</html>