<?php  
  session_start();
  //include("manager-login.php");
  
  $db = mysqli_connect('localhost','root','','bbms');
  if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
  }
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Manager control</title>
	<!--<link rel="stylesheet" type="text/css" href="manager-profile.css">-->
</head>

<style>
 @import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap");
* {
  margin: 0;
  padding: 0;
  list-style: none;
  box-sizing: border-box;
  font-family: "Montserrat", sans-serif;
}

body {
  
  font-size: 14px;
  line-height: 24px;
}

.wrapper {
  background: none;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 1360px;
  height: 650px;
  display: flex;
  border-radius: 15px;
}

.wrapper .wrapper_left {
  width: 300px;
  background: black;
  padding: 0 25px;
  margin: 0px;
  display: flex;
  align-items: center;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
  box-shadow: 10px 0px 13px 0px rgba(41, 41, 57, 0.7);
  height: 100%;
}
.wrapper .wrapper_left ul li {
  background: #313142;
  margin-bottom: 15px;
  border-radius: 0px 20px 0px 20px;
  padding: 12px 25px;
  text-transform: uppercase;
  font-weight: 500;
  position: relative;
  overflow: hidden;
  width: 250px;
  letter-spacing: 2px;
  transition: all 0.4s ease;
  cursor: pointer;
}

.wrapper .wrapper_left ul li p {
  color: white;
  position: relative;
}

.wrapper .wrapper_left ul li:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background: #5437b7;
  background: linear-gradient(
    126deg,
    rgba(2, 0, 36, 1) 0%,
    rgba(123, 90, 231, 1) 0%,
    rgba(88, 54, 206, 1) 100%
  );
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transition: all 0.4s ease;
}

.wrapper .wrapper_left ul li.active {
  width: 250px;
}
.wrapper .wrapper_left ul li.active p {
  color: #fff;
}
.wrapper .wrapper_left ul li.active:before {
  width: 100%;
  transition: all 0.2s ease;
}

.wrapper .wrapper_left ul li:last-child {
  margin-bottom: 0;
}

.wrapper .wrapper_right {
  background: url(m2.jpg);
  background-repeat: no-repeat;
  width: 1500px;
  padding: 30px 50px;
  }

.wrapper .wrapper_right .title {
  width: 600px;
  font-size: 24px;
  text-align: center;
  font-weight: 700;
  color: white;
  margin-bottom: 10px;
  text-transform: uppercase;
}

.wrapper .wrapper_right .item .item_info {
  display:inline;
  justify-content: space-around;
  align-items: left;
}






.wrapper .wrapper_right .item .item_info p {
  background: #fff;
  width: 400px;
  padding: 10px;
  border-radius: 5px;
  color: #abaacd;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
}
.wrapper .wrapper_right .item.Profile .item_info p {
  color: #dd0330;
}
.wrapper .wrapper_right .item.Blood_donors .item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.Blood_groups .item_info p {
  color: #61dafb;
}
.wrapper .wrapper_right .item.Add_Blood_Bank .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.Add_receptionist .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.Add_blood_group .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.stock_list .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.Orders .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.logout .item_info p.txt{
  color: black;
}
.wrapper .wrapper_right .item.angular .item_info p {
  color: #dd0330;
}
.wrapper .wrapper_right .item.nodejs .item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.reactjs .item_info p {
  color: #61dafb;
}
.wrapper .wrapper_right .item.vuejs .item_info p {
  color: #41b783;
}

.wrapper .wrapper_right .item p {
  margin-bottom: 20px;
  color: #fff;
}
table.t1 {
  text-transform: uppercase;
  border-collapse: collapse;
  border-radius: 40px;
  width: 100%;
}
table.t1 th{
  background-color: black;
  color: white;
}
table.t1 th, td {
  text-align: center;
  padding: 8px;
  font-family: "rubik";
}
table.t1 tr:nth-child(odd) {background-color:#d6d6c2;}
table.t1 tr:nth-child(even) {background-color: #ffffb3;}

table.t2{
  margin-top: 0px;
  text-transform: uppercase;
  width: 50%;
  margin-left: 20px;
  background-color: grey;
  opacity: 0.7;
  border:1px solid black;
  border-radius: 20px;
}
table.t2 caption{
  color: #ffbb99;
  font-size: 28px;
  font-family: "rubik";
  margin-bottom: 5px;
  text-align: center;
}
  table.t2 th{
    color: black;
    font-family: times new roman;
    font-size: 20px;
    text-align: right;
    border-bottom: 1px white;
  }
  table.t2 td{
    text-align: left;
        color: white;
        font-family: "rubik";
        font-size: 20px;

  }
  table.t2 td.email{
    text-transform: lowercase;
  }



  div.img{
    width: 250px;
    height: 230px;
    border-width: 150px;
    border-radius: 100px;
    border-color: red;
    text-align:  center;
  }
  .img{
    margin-left: 80px;
    margin-bottom: 0px;
    background-image: url("manage1.png");
    align-content: center;
  }
  a{
    text-decoration: none;
    color: white;
  }
  a:hover{
    color:red;
  }
  label.txt{
    background: #fff;
    margin-top: 250px;
  width: 800px;
  padding: 10px;
  border-radius: 5px;
  color: green;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
  }
  .wrapper .wrapper_right .item .item_info .logt{
    background-color: black;
    color: red;
    width: 400px;
    border-radius: 20px;
    margin-top: 250px;

  }
</style>
<body>
<div class="wrapper">
  <div class="wrapper_left">
  <ul>
      <li data-li="Profile">
        <p>Profile</p>
      </li>
      <li data-li="Blood_donors">
        <p>Blood Donors</p>
      </li>
      <li data-li="Blood_groups">
        <p>Blood Bank</p>
      </li>
      <!--<li data-li="Add_Blood_Bank">
        <p>Add Blood Bank</p>
      </li>-->
      <li data-li="Add_receptionist">
        <p>ADD RECEPTIONIST</p>
      </li>
      <!--<li data-li="Add_blood_group">
        <p>Add Blood Groups</p>
      </li>-->
      <li data-li="stock_list">
        <p>Stock List</p>
      </li>
      <li data-li="orders">
        <p>Orders</p>
      </li>
      <li data-li="update">
        <p>update details</p>
      </li>
      <li data-li="cpass">
        <p>Change password</p>
      </li>
      <li data-li="logout">
        <p>Logout</p>
      </li>
    </ul>
  </div>
  <div class="wrapper_right">
    <div class="title">
	  MANAGER PANEL
    <?php

    //$query="SELECT Fname from blood_bank_manager where MID=$id";
    //$result=mysqli_query($db,$query);
    
    //if (mysqli_num_rows($result)>0) {
    //  while($row=mysqli_fetch_array($result))
     //     echo $row;
    // } 
    
   // echo "failed to get:".$mysqli->error;
    ?>
    </div>
    <div class="container">
      <div class="item Profile" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Profile</p>
          <div class="img"></div>
          <?php  include("manager-profile.php"); ?>

        </div>
	</div>
      <div class="item Blood_donors" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>DONOR LIST</p>
          <?php include("donor-list.php");?>
        </div>
	 </div>
   <div class="item Blood_groups" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>BLOOD BANK</p>
          <?php include("blood_bank.php"); ?>
        </div>
   </div>
   <!--<div class="item Add_Blood_Bank" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>ADD BLOOD BANK</p>
        </div>
   </div>-->
   <div class="item Add_receptionist" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Add Receptionist</p>
          <?php include("receptionist.php"); ?>
        </div>
   </div>
   <!--<div class="item Add_blood_group" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>ADD BLOOD GROUP</p>
        </div>
   </div>-->
   <div class="item stock_list" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>STOCK LIST</p>
          <?php include("stock-list.php"); ?>
        </div>
   </div>
      <div class="item orders" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>ORDERS</p>
          <?php include("orders.php"); ?>
        </div>
       </div>
        <div class="item update" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>UPDATE DETAILS</p>
          <?php include("manager-update.php"); ?>
        </div>
       </div>
       <div class="item cpass" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Change Password</p>
          <?php include("manager-password.php"); ?>
        </div>
       </div>
    <div class="item logout" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p class="logt">Do You Really Want to Logout?<br><a href="manager-login.php">Click Here</a></p>
          <?php //include("logout.php"); ?>
        </div>
       </div>
  </div>
</div>
	<script>
var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "Profile") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Blood_donors") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Blood_groups") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Add_Blood_Bank") {
      document.querySelector("." + li_value).style.display = "block";
    }  else if (li_value == "Add_receptionist") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "Add_blood_group") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "stock_list") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "orders") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "update") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "cpass") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "logout") {
      document.querySelector("." + li_value).style.display = "block";
    }
    else {
      console.log("");
    }
  });
}
	</script>

</body>

</html>