<?php 	include "connection.php";
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>DONOR</title>
	<style>
	@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap");
* {
  margin: 0;
  padding: 0;
  list-style: none;
  box-sizing: border-box;
  font-family: "Montserrat", sans-serif;
}
body {
background-image: url(lr.jpg);
  font-size: 14px;
  line-height: 24px;
}

.wrapper {
	background-image: url(lr.jpg);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width:1360px;
  height: 650px;
  display: flex;
  border-radius: 15px;
}

.wrapper .wrapper_left {
  width:260px;
  padding: -25px 25px;
  display: flex;
  align-items: center;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
  box-shadow: 10px 0px 13px 0px rgba(41, 41, 57, 0.7);
}
.wrapper .wrapper_left ul li {
  background: #313142;
  margin-bottom: 25px;
  border-radius: 3px;
  padding: 12px 25px;
  text-transform: uppercase;
  font-weight: 500;
  position: relative;
  overflow: hidden;
  width: 230px;
  letter-spacing: 2px;
  transition: all 0.4s ease;
  cursor: pointer;
}

.wrapper .wrapper_left ul li p {
  color: #abaacd;
  position: relative;
}

.wrapper .wrapper_left ul li:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background:white;
  background:(
    126deg,
    rgba(2, 0, 36, 1) 0%,
    rgba(123, 90, 231, 1) 0%,
    rgba(88, 54, 206, 1) 100%
  );
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transition: all 0.4s ease;
}

.wrapper .wrapper_left ul li.active {
  width: 230px;
}
.wrapper .wrapper_left ul li.active p {
  color: black;
}
.wrapper .wrapper_left ul li.active:before {
  width: 100%;
  transition: all 0.2s ease;
}

.wrapper .wrapper_left ul li:last-child {
  margin-bottom: 0;
}

.wrapper .wrapper_right {	
  width: 1000px;
  padding: 20px 70px;
}

.wrapper .wrapper_right .title {
  font-size: 24px;
  text-align:center;
  font-weight: 700;
  color: #0000FF;
  margin-bottom: 20px;
  text-transform: uppercase;
}

.wrapper .wrapper_right .item .item_info {
	width: 300px;
 			margin: 0 auto;
 			color: white;
  display:inline;
  justify-content: space-around;
  align-items:center;
}
.wrapper .wrapper_right .item .item_info .img img{
	left:40%;
  width: 125px;
  height: 125px;
  background: #fff;
  border-radius: 50%;
  margin-bottom: 20px;
  position: relative;
  align-items:center;
}
.wrapper .wrapper_right .item .item_info .img:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: url("frames.png") no-repeat 0 0;
  width: 94px;
  height: 101px;
}
.wrapper .wrapper_right .item.Profile .item_info .img:before {
  background-position: 0 0;
  width: 94px;
  height: 101px;
}

.wrapper .wrapper_right .item .item_info p {
	background: #313142;
  width: 200px;
  padding: 10px;
  border-radius: 5px;
  color: #fff;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
  margin-left:330px;
}
.wrapper .wrapper_right .item.Profile .item_info p {
  color: skyblue;
}
.wrapper .wrapper_right .item.Donation_details.item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.logout.item_info p {
  color: #8bc500;
  width: 600px;
}
.wrapper .wrapper_right .item.Update.item_info p {
  color: #8bc500;
  margin-left:350px;
}
.wrapper .wrapper_right .item .item_info p.log{
  color: red;
  width: 380px;
  background-color: black;
  margin-top: 200px;
  margin-left: 50px;
  padding: 5px;
  font-size: 20px;
  font-family: "rubik";
}
a{
  text-decoration: underline;
  color: white;
  
  text-transform: uppercase;
  font-family: "rubik";
}
a:hover{
  color: cyan;
}

.wrapper .wrapper_right .item .Update .f1{
            
            margin-left:350px;
            padding: 20px;
          }
</style>
</head>
<body>
<div class="wrapper">
  <div class="wrapper_left">
  <ul>
      <li data-li="Profile" class="active">
        <p>Profile</p>
      </li>
	   <li data-li="Update">
        <p>Profile Update</p>
      </li>
	   <li data-li="Donation_details">
        <p>Donation_details</p>
      </li>
      <li data-li="logout">
        <p>logout</p>
      </li>
    </ul>
  </div>
  <div class="wrapper_right">
    <div class="title">
	  DONOR
    </div>
    <div class="container">
      
		    <div class="item Update" style="display: none;">
        <div class="item_info"><p>Profile Update</p></div>
		 <?php include "Dupdate.php";?>
	 </div>
	  <div class="item logout" style="display: none;">
        <div class="item_info">
		<p class="log">Do you want to logout:<br><a href="donor_login.php">yes</a> or <a href="#">no</a></p>
		</div>
		
       </div>
      <div class="item Donation_details" style="display: none;">
        <div class="item_info"><p>Donation_details</p></div>
     <?php include "donation.php";?>
	 </div>
 <div class="item Profile" style="display:none;">
        <div class="item_info">
   <div class="img">
   <img src="Dprofile.png"></img></div>
   <p>Profile</p></div>
    <?php include "Dprofile.php";?>
  </div>
	   </div>
  </div>
</div>
	<script>
var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "Profile") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Donation_details") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Update") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "logout") {
      document.querySelector("." + li_value).style.display = "block";
    } else {
      console.log("");
    }
  });
}
	</script>
</body>
</html>