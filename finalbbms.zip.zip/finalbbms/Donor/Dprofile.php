<?php 
	include "connection.php";
	if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
	?>
	<style>
	.table{
		width: 40%;
		background-color: white;
		opacity: 0.8;
		color:black;
	text-align:center;
	border-collapse:collapse;
	margin:10px 0;
	font-size:15px;
	font-weight:bold;
	 margin-left: 250px;
 margin-top: 10px;
border-radius: 30px 5px 20px 5px;
text-transform: capitalize;
}
.table .tr1 .td1{
color:black;
	text-align:right;
	font-weight:bold;

padding:5px 5px;	
	border-bottom:1px;
	padding-right: 20px;
}
.table .tr1 .td2{
color:black;
	text-align:left;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-left: 20px;
}
.table .tr2 .td3{
color:black;
	text-align:right;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-right: 20px;
}
.table .tr2 .td4{
color:black;
	text-align:left;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-left: 20px;
}
.table .tr3 .td5{
color:black;
	text-align:right;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-right: 20px;
}
.table .tr3 .td6{
color:black;
	text-align:left;
	font-weight:bold;	
	padding:5px 5px;
	border-bottom:2px;
	padding-left: 20px;
}
.table .tr4 .td7{
color:black;
	text-align:right;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-right: 20px;
}
.table .tr4 .td8{
color:black;
	text-align:left;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-left: 20px;
}
.table .tr5 .td9{
color:black;
	text-align:right;
	font-weight:bold;	
	padding:5px 5px;
	border-bottom:2px;
	padding-right: 20px;
}
.table .tr5 .td10{
color:black;
	text-align:left;
	font-weight:bold;
padding:5px 5px;	
	border-bottom:2px;
	padding-left: 20px;
}
</style>
	<?php
 				$qr="select DID,Fname,Lname,DOB,Gender,ph_no,R_DID from donor where DID='$id'";
				$result=$conn->query($qr)or die(mysqli_error());
				$qr1="select house_no,street,area,pincode from address where DID='$id'";
				$result1=$conn->query($qr1)or die(mysqli_error());
				$qr2="select city,state from daddress2 b,address d where  b.pincode=d.pincode and d.DID='$id'";
				$result2=$conn->query($qr2)or die(mysqli_error());
			
			
			
			if ($result->num_rows>0)
			{	
			while($row=$result->fetch_assoc())
			{
 				//echo "<div style='text-align: center'>
 				//	<img class='img-circle profile-img' height=110 width=120 src='C:\Users\130cs\Pictures\Saved Pictures\hostel.jpg'".$_SESSION['pic']."'>
 				//</div>";
	 				// echo $_SESSION['id'];
					?>
 				<b>
 			<table class='table'>
	 				<tr class="tr1">
	 					<td class="td1">
	 		<b> Name</td><td>:</td><td class="td2"><?php echo $row['Fname']." ".$row['Lname'];?></td>
	 				</tr>
					
					<tr class ="tr3">
					<td class="td5"><b> Date of Birth</td><td>:</td>
	 					<td class="td6"><?php 	echo $row['DOB'];?>
	 					</td>
						</tr>
						<tr class="tr4">
						<td class="td7">
						<b>Gender </td><td>:</td>
	 						<td class="td8"><?php echo $row['Gender'];?>
	 					</td>
						</tr>
						<tr class="tr5">
						<td class="td9">
						<b> Phone-No  </td><td> :</td>
						<td class="td10"><?php echo $row['ph_no'];?>
	 					</td>
						</tr>
						<?php
						}
						if($result1->num_rows>0)
						{
						while($row1=$result1->fetch_assoc())
						{ ?>
						<tr class="tr5">
						<td class="td9">
						<b> House_no </td><td> :</td>
						<td class="td10"><?php echo $row1['house_no'];?>
	 					</td>
						</tr>
						<tr class="tr5">
						<td class="td9">
						<b> Street</td><td> :</td>
						<td class="td10"><?php echo $row1['street'];?>
	 					</td>
						</tr>
						<tr class="tr5">
						<td class="td9">
						<b> Area</td><td> :</td>
						<td class="td10"><?php echo $row1['area'];?>
	 					</td>
						</tr>
						<?php
						if($result2->num_rows>0)
						{
						while($row2=$result2->fetch_assoc())
						{
						?>
						<tr class="tr5">
						<td class="td9">
						<b> City</td><td> :</td>
						<td class="td10"><?php echo $row2['city'];?>
	 					</td>
						</tr>
						<tr class="tr5">
						<td class="td9">
						<b>State</td><td> :</td>
						<td class="td10"><?php echo $row2['state'];?>
	 					</td>
						</tr>
						<tr class="tr5">
						<td class="td9">
						<b> Pincode</td><td> :</td>
						<td class="td10"><?php echo $row1['pincode'];?>
	 					</td>
						</tr>
						
					</table>
 				</b>
				<?php 
						}
			}
			}
			}
			}
			}
			?>