<?php 
include "connection.php";
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


  //$db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  ?>
  <form class="f1" action="#" method="post" align="center"  autocomplete="off">
  	<b><label class="l1">Donor ID</label><label class="l2">:</label><label class="l3"><?php echo $_SESSION['id'];?></label><br>
    <input type="text"  name="fname" class="fname" placeholder="First name" required>
    <input type="text"  name="lname" class="lname" placeholder="Last name"><br>
   <input type="Date" name="dob" class="dob" required><br>
<!-- <input type="text" name="gender" class="gender"  placeholder="gender" required><br>-->  
  
   <input type="text" name="house_no" class="address1" placeholder="House no"required><br>
	<input type="text" name="street" class="address2" placeholder="Street"required><br>
	<input type="text" name="area" class="address3" placeholder="Area"required><br>
	<input type="text" name="city" class="address4" placeholder="City"required><br>
	<input type="text" name="state" class="address5" placeholder="State"required><br>
	<input type="number" name="pincode" class="address6" placeholder="Pincode"required><br>
  <input type="number"  name="ph_no" class="ph_no" placeholder="Phone no" required><br>
          <input type="submit" name="update" class="btn" value="UPDATE"></b><br>
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
      
      
    

  <?php
      if(isset($_POST['update']))
	  {
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$dob = $_POST['dob'];
	//$gender = $_POST['gender'];
	$phno = $_POST['ph_no'];
	$house_no = $_POST['house_no'];
	$street = $_POST['street'];
	$area = $_POST['area'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$pincode = $_POST['pincode'];

       $qr1="UPDATE donor SET Fname='$fname',Lname='$lname',DOB='$dob',ph_no='$phno' WHERE DID='$id'";    
      $up = "SELECT * FROM daddress2 WHERE pincode = '$pincode'";
      $up4="INSERT into daddress2 VALUES('$pincode','$city','$state')";
      $up2 = "UPDATE daddress2 SET  city = '$city', state = '$state' WHERE pincode = '$pincode'";
      $uq3 = "UPDATE address SET Street = '$street', area = '$area', pincode = '$pincode' WHERE DID = '$id'";
	  
	  
     $rup=mysqli_query($conn,$qr1)or die(mysqli_error());
      $rup1= mysqli_query($conn,$up)or die(mysqli_error());
    
      if($rup){
        if(mysqli_num_rows($rup1) > 0) {
          $rup42 = mysqli_query($conn,$up2)or die(mysqli_error());
		}
        else {
          $rup42 = mysqli_query($conn,$up4)or die(mysqli_error());
		}
      if($rup42){
        $ruq3 = mysqli_query($conn,$uq3)or die(mysqli_error());
        echo "<script type='text/javascript'> alert('updated successfully')</script>";
      }
      else
        echo "<h6><script type='text/javascript'> alert('Not Updated Check Once Again')</script></h6>";
    }
  }
}
  ?>
</form>
         <style>
           h6{
            text-transform: capitalize;
            font-size: 20px;
            font-family: "rubik";
            color: pink;
            font-style: italic;
          }
      .f1{
        margin-top: 30px;
       width: 300px;
      margin-left:280px;
      padding:10px;
			color:#fff;
			font-weight:bold;
      background-color: grey;
      border-radius: 20px;
          }
	 .l1{
			  margin-left:5px;
			
		  }
		 .l2{
			   margin-left:10px;
			
		  }
		   .l3{
			   margin-left:10px;
	
		  }
         .fname, .lname , .dob,.gender, .ph_no, .address1, .address2, .address3, .address4, .address5, .address6{
            padding: 5px;
            padding-left: 20px;
            margin-bottom: 10px;
            border: none;
            outline: none;
            background-color:transparent;
            font-size: 12px;
            text-align:center;
			     color:#fff;
			     font-weight:bold;
           border-bottom: 2px solid white;
          }
          .fname, .lname{
            width: 80px;
          }
         ::placeholder{
            opacity: 1;
            color: white;
            font-size: 14px;
			font-weight:bold;
          }
         .wrapper .wrapper_right .item .item_info .btn{
            border:2px solid white;
            background-color: transparent;
            color: black;
            background-color: yellow;
            border-radius: 30px ;
            padding: 10px;
          } 
          .btn{
            padding: 5px;
            font-size: 15px;
            text-transform: capitalize;
            outline: none;
            border-radius: 20px;
          }
          .btn:hover{
            background-color: red;
            color: white;
          }
         </style>          
          
