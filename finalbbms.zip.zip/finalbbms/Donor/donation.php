<?php
include "connection.php";
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
	?>

?>
<style>
.D2{
	text-align:center;
	border-collapse:collapse;
	margin:25px 0;
	font-size:16px;
	width:100%;
	margin-left:50px;
	font-weight:bold;
	text-transform: uppercase;

}
.D2 th{
	color:#fff;
	width: 100px;
	text-align:center;
	font-weight:bold;	
}
.D2 td{
	text-align: center;
	padding:5px;
	color:red;
	background-color: cyan;
	border-radius: 0px;
	border-bottom:1px solid black;
}
</style>
<table class="D2">
<?php
$qr="select Fname,Lname,D_date,blood_type,Amount,code,BBID from donor,blood where DID = B_DID and DID='$id'";
$result=$conn->query($qr);
if ($result->num_rows>0) 
{
    echo"<tr><th>code</th><th>Blood Bank</th><th>Name</th><th>Blood Type</th><th>Amount</th><th>D_date</th></tr>";
	// output data of each row
    while($row=$result->fetch_assoc()) 
	{
        echo "<tr><td>".$row["code"]."</td><td>".$row["BBID"]."</td><td>".$row["Fname"]." ".$row["Lname"]."</td><td>".$row["blood_type"]."</td><td>".$row["Amount"]."</td><td>".$row["D_date"]."</td></tr>";
    }
    
?>
</table>
</div>
<?php
}
else
{
    echo "<tr><td>0 results</td></tr>";
}
}
$conn->close();

?>