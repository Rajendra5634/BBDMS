<?php 
	session_start();
	//include("manager-login.php");
	
	$db = mysqli_connect('localhost','root','','bbms');
	if($_SESSION['id'] == true)
		$id= $_SESSION['id'];
	$_SESSION['success'] = "You are now logged in";
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>manager control panel</title>
	
<style type="text/css">
	*{
		margin: 0px;
		padding: 0px;
		list-style: none;
		text-decoration: none;
	}
	body{
		background-color: grey;
		color: black;
		font-family: "Roboto",sans-serif;
	}
	.sidebar{
		position: absolute;
		left: -250px;
		width: 250px;
		height: 100%;
		background: black;
		transition: all .5s ease;
	}
	::-webkit-scrollbar{
		width: 25px;
	}
	::-webkit-scrollbar-track{
		border:7px solid black;
		box-shadow: inset 0 0 2.5px 2px rgba(0,0,0,0.5);
	}
	::-webkit-scrollbar-thumb{
		background: linear-gradient(
			45deg,
			#06dee1,
			#79ff6c
			);
		border-radius: 5px;
	}
	.sidebar header{
		color:white;
		font-size: 22px;
		text-align: center;
		line-height: 70px;
		background: #063146;
		user-select: none;
	}
	.sidebar ul a{
		display: block;
		height: 100%;
		width: 100%;
		line-height: 50px;
		font-size: 20px;
		color: white;
		padding-left: 40px;
		box-sizing: border-box;
		border-top: 1px solid rgba(255,255,255,-1);
		border-bottom: 1px solid grey;
		transition: .4s;
	}
	ul li:hover a{
		padding-left: 50px;
		background-color: pink;
		color: black;
	}
	.sidebar ul a i{
		margin-right: 16px;
	}
	.wrapper{
		float: right;
		position: absolute;
		background-color: white;
		color:black;
		margin-left:19%;
		margin-right: 0%;
		width: 80%;
		height: 100%;
	}
	#check{
		display: none;
	}
	label #btn,label #cancel{
		position: absolute;
		cursor: pointer;
		background: #042331;
		border-radius: 3px;
	}
	label #btn{
		left: 40px;
		top: 25px;
		font-size: 35px;
		color: white;
		padding: 6px 12px;
		transition: all .5s;
	}
	label #cancel{
		z-index: 1111;
		left:-195px;
		top: 17px;
		font-size: 25px;
		color: white;
		background: black;
		border-radius: 40px;
		padding: 4px 9px;
		transition: all .5s ease;
	}
	#check:checked ~ .sidebar{
		left: 0;
	}
	#check:checked ~ label #btn{
		left: 250px;
		opacity: 0;
		pointer-events: none;
	}
	#check:checked ~ label #cancel{
		left: 195px;
	}
	#check:checked ~ section{
		margin-left: 250px; 
	}
	section{
		background: url("bb1.jpg");
		background-position: center;
		background-size: cover;
		height: 100vh;
		transition: all .5s;
	}
	.wrapper .wrapper_right {
  width: 1000px;
  padding: 30px 50px;
}

.wrapper .wrapper_right .title {
  font-size: 24px;
  text-align: center;
  font-weight: 700;
  color: #6b6b93;
  margin-bottom: 20px;
  text-transform: uppercase;
}

.wrapper .wrapper_right .item .item_info {
  display:inline;
  justify-content: space-around;
  align-items: left;
}
.wrapper .wrapper_right .item .item_info .img {
  width: 200px;
  height: 200px;
  background: #fff;
  border-radius: 50%;
  margin-bottom: 20px;
  position: relative;
}

.wrapper .wrapper_right .item .item_info .img:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: url("frames.png") no-repeat 0 0;
  width: 94px;
  height: 101px;
}

.wrapper .wrapper_right .item.angular .item_info .img:before {
  background-position: 0 0;
  width: 94px;
  height: 101px;
}
.wrapper .wrapper_right .item.nodejs .item_info .img:before {
  background-position: 0 -110px;
  width: 89px;
  height: 101px;
}
.wrapper .wrapper_right .item.reactjs .item_info .img:before {
  background-position: 0 -220px;
  width: 100px;
  height: 100px;
}
.wrapper .wrapper_right .item.vuejs .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}

.wrapper .wrapper_right .item .item_info p {
  background: #fff;
  width: 150px;
  padding: 10px;
  border-radius: 5px;
  color: #abaacd;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
}
.wrapper .wrapper_right .item.angular .item_info p {
  color: #dd0330;
}
.wrapper .wrapper_right .item.nodejs .item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.reactjs .item_info p {
  color: #61dafb;
}
.wrapper .wrapper_right .item.vuejs .item_info p {
  color: #41b783;
}

.wrapper .wrapper_right .item p {
  margin-bottom: 20px;
  color: #fff;
}
</style>
</head>
<body>
	<div>
	<input type="checkbox" id="check">
	<label for="check">
		<i class="fa fa-bars" id="btn"></i>
		<i class="fa fa-times" id="cancel"></i>
	</label>
	<div class="sidebar" id="sidebar">
		<?php
		$query="SELECT Fname from blood_bank_manager where MID=$id";
		$result=mysqli_query($db,$query);
		
		if ($db->mysqli_query($query)==true) {
			$result=mysqli_fetch($query);
		 	echo $result;
		 } 
		
		echo "<header>Welcome</header>".$query;
		?>
			<ul>
				<li><a href="frontpage.html"><i class="fa fa-times"></i>Home</a></li>
				<li><a href="#"><i class="fa fa-qrcode"></i>Profile</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Blood Donors</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Blood Groups</a></li>
				<li><a href="#"><i class="fa fa-link"></i>Add BloodBank</a></li>
				<li><a href="#"><i class="fa fa-link"></i>Add Receptionist</a></li>
				<li><a href="#"><i class="fa fa-link"></i>Add BloodGroup</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Stock List</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Orders</a></li>
				<li><a href="#"><i class="fa fa-times"></i>logout</a></li>
			</ul>
	</div>
	<div class="wrapper_right">
    <div class="title">
	  DONOR
    </div>
    <div class="container">
      <div class="item Profile">
        <div class="item_info">
          <div class=""></div>
          <p>Profile</p>
        </div>

	</div>
      <div class="item Donation_details" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Donation_details</p>
        </div>
     
	 </div>
      <div class="item phone_no" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>phone_no</p>
        </div>
       </div>
  	   </div>
	</div>
</div>
	<!--<section></section>-->
	<script>
var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "Profile") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Donation_details") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "phone_no") {
      document.querySelector("." + li_value).style.display = "block";
    }  else {
      console.log("");
    }
  });
}
	</script>
</body>
</html>