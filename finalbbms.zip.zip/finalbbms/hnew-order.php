<?php 
if($_SESSION['hosid'] == true){
    $id= $_SESSION['hosid'];
  $_SESSION['success'] = "You are now logged in";
$db = mysqli_connect('localhost','root','','bbms') or die('not connected to database');

 ?>
 <form class="add" method="post" autocomplete="off" align="center"	action="#">
 	<label class="new">enter blood bank id :</label>
 	<input type="text" name="hbbid" class="hbbid" required placeholder="enter blood bank ID"><br>
 	<label class="new">enter orders for A+ :</label>
 	<input type="number" name="A+" class="bbid" placeholder="A+"><br>
 	<label class="new">enter orders for A- :</label>
 	<input type="number" name="A-" class="bbid" placeholder="A-"><br>
 	<label class="new">enter orders for B+ :</label>
 	<input type="number" name="B+" class="bbid" placeholder="B+"><br>
 	<label class="new">enter orders for B- :</label>
 	<input type="number" name="B-" class="bbid" placeholder="B-"><br>
 	<label class="new">enter orders for AB+ :</label>
 	<input type="number" name="AB+" class="bbid" placeholder="AB+"><br>
 	<label class="new">enter orders for AB- :</label>
 	<input type="number" name="AB-" class="bbid" placeholder="AB-"><br>
 	<label class="new">enter orders for O+ :</label>
 	<input type="number" name="O+" class="bbid" placeholder="O+"><br>
 	<label class="new">enter orders for O- :</label>
 	<input type="number" name="O-" class="bbid" placeholder="O-"><br>
 	<input type="submit" value="apply order" name="submit" class="button"><br>
 

<?php 
	if(isset($_POST['hbbid'])){
		$bid = $_POST['hbbid'];
		$A1 = $_POST['A+'];
		$A2 = $_POST['A-'];
		$B1 = $_POST['B+'];
		$B2 = $_POST['B-'];
		$AB1 = $_POST['AB+'];
		$AB2 = $_POST['AB-'];
		$O1 = $_POST['O+'];
		$O2 = $_POST['O-'];
	$add = "SELECT SUM(`A+`+`A-`+`B+`+`B-`+`AB+`+`AB-`+`O+`+`O-`) AS total_orders FROM horders where HID='$id' AND HBBID = '$bid'";	
	$shift = "SELECT HBBID,HID FROM horders,blood_bank WHERE HBBID=BBID AND HBBID='$bid' AND HID= '$id'";
	$ins = "INSERT INTO horders VALUES('$id','$bid','$A1','$A2','$B1','$B2','$AB1','$AB2','$O1','$O2')";
	$check = "SELECT * FROM blood_bank WHERE BBID = '$bid'";
	$rcheck = mysqli_query($db,$check);
	$rshift = mysqli_query($db,$shift);
	if(mysqli_num_rows($rcheck) > 0){
		if(mysqli_num_rows($rshift) > 0){
		
		echo "<h2><script type='text/javascript'> alert('Order Already Applied')</script></h2>";
	}
	else{
		$rin = mysqli_query($db, $ins);
		$radd = mysqli_query($db, $add);
		while($row=mysqli_fetch_array($radd))
			$total = $row['total_orders'];
		$uporder = "UPDATE blood_bank SET orders = orders+'$total' WHERE BBID = '$bid'";
		$ruporder = mysqli_query($db, $uporder);
		echo "<h2><script type='text/javascript'> alert('Order Applied Successfully')</script>Order Applied Successfully</h2>";}
	}
	else 
		echo "<h2><script type='text/javascript'> alert('Invalid Blood Bank Entry: to order')</script></h2>";
 	}
 }

 ?>
</form>
 <style>
 	h2{
 		text-transform: capitalize;
 		font-size: 25px;
 		font-family: "rubik";
 		color: white;
 	}
 	.add{
 		margin: 0px;
 		margin-left: 150px;
 		width: 500px;
 		box-sizing: border-box;
 		border: 2px solid black;
 		color: white;
 		padding: 20px;
 		outline: none;
 		border-radius: 25px;
 		background-color: #606157;
 	
 	}
 	.bbid{
 		text-transform: uppercase;
 		border-radius: 20px solid black;
 		outline: none;
 		font-weight: 500;
 		font-size: 24px;
 		font-style: bold;
 		text-align: center;
 		color: pink;
 	}
 	.new{
 		width: 200px;
 		display: inline-block;
 		margin-right: 0px;
 		text-transform: capitalize;
 		font-size: 18px;
 		font-family: "rubik";
 		text-align: right;
 	}
 	.bbid, .hbbid{
 		width: 80px;
 		padding: 10px;
 		margin-bottom: 10px;
 		outline: none;
 		border-radius: 20px;
 		background-color: transparent;
 	}
 	.hbbid{
 		text-align: center;
 		width: 200px;
 		font-size: 24px;
 		color: pink;
 	}
 	.bbid::placeholder{
 		font-weight: 500;
 		font-size: 16px;
 	}
 	.hbbid::placeholder{
 		text-align: center;
 		text-transform: capitalize;
 		font-weight: 500;
 		font-size: 16px;
 	}
 	.button{
 		outline: none;
 		text-transform: uppercase;
 		padding: 15px;
 		font-family: "rubik";
 		font-size: 15px;
 		background-color: black;
 		color: green;
 		border:1px solid black;
 		border-radius: 20px;
 	
 	}
 	.button:hover{
 		background-color: red;
 		color: white;
 	}
 </style>