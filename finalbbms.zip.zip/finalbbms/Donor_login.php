<?php
//establishing connection
$db = mysqli_connect('localhost', 'root', '', 'bbms');
// LOGIN USER


?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>home/Donor login</title>

<link href="http://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
<style type="text/css">
	*{
margin: 0;
padding: 0;
box-sizing: border-box;
text-decoration: none;
}
body{

font-family: 'Raleway', sans-serif;
background-image: url(lo.jpg);
color: black;
}
.background{
background-image: url(lo.jpg); 
margin: 0px;
padding-bottom: 110px;
background-size: cover;
background-position: center;
width: 100%;
display: flex;
}
.text, .box{
margin-top: 45vh;
}
.login{
margin-left: 10%;
font-weight: 300px;
}
.box{
margin-top: 210px;
margin-left: 9%;
flex: 1;
}
.text h1{
font-size: 70px;
color: #fff;
font-weight: 500;
}
.text p{
font-size: 20px;
color: black;
font-weight: 300;
font-style: bold;
padding-bottom: 70px;
}
.text p a{
color: #fff;
font-weight: 700;
}
.text p a:hover{
	color: red;
}
.text p i{
	margin: 0px;
	padding: 0px;
	color:orange;
	font-style: italic;
	font-size: 16px;
}
.form{
background: white;
color: black;
box-sizing: border-box;
display: flex;
flex-direction: column;
width: 250px;
opacity: 0.9;
padding-left: 20px;
border-radius: 20px;
}
img{
	border-image: white;
	margin: 0px;
	width: 70px;
	height: 60px;
}
label{
	margin:10px 5px;
	padding: 0px;
	float: right;
	font-size: 20px;
	font-family: times new roman;
	font-style: bold italic;
	flex-direction: absolute;
	color: black;
}
input{
float: left;
margin: 5px 0;
padding: 10px;
background: transparent;
border: none;
outline: none;
color: black;
font-family: arial, sans-serif;
}
.id, .phno{
	float: left;
border: 2px solid black;
border-radius: 20px;
}
.button{
background: transparent;
color: black;
border: 1px solid black;
font-size: 19px;
border-radius: 20px;
width: 150px;
}
.button:hover{
background: black;
color: #fff;
}
</style>
</head>
<body>
<main>
<div class="background">
<div class="text">
<h1>Donor Login</h1>
<p><b>No Account?</b><a href="frontpage.html">Go Back To Home</a></p>
<P><i><b>Note:</b> You must Register before Login</i></P>
</div>
<div class="box">
<form class="form" method="post" action="#" autocomplete="off">
	<img src="user-logo.png">
	<label>Donor ID:<input type="text" name="id" class="id" placeholder="Donor-ID"required></label>
	<label>Phone No:<input type="number" name="phno" class="phno" placeholder="phone-no"required></label>
	<?php
		if (isset($_POST['id'])) {
  $id = $_POST['id'];
  $phno = $_POST['phno'];

    //$password = md5($password);
    $query = "SELECT * FROM donor WHERE DID='$id' AND ph_no='$phno'";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['id'] = $id;
      if($_SESSION['id'] = $id){
      $_SESSION['success'] = "You are now logged in";
      header('location: frontpage.html');
    }
  }
  else {
      echo"Wrong username/password combination";
    }
}
	  ?>
<input type="submit" class="button" value="login">
</form>
</div>
</div>
</main>
</body>
</html>