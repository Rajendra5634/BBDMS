<?php 
//session_start();
$db = mysqli_connect('localhost','root','','bbms');
if($_SESSION['hosid'] == true){
    $id= $_SESSION['hosid'];
  $_SESSION['success'] = "You are now logged in";
  

  $query1= "SELECT h.`HID`,HName,phno, Street,Area,City,State,p.`pincode` from `hospital` h,`haddress1` a,`haddress2` p WHERE h.`HID` = '$id' AND h.`HID`= a.`HID` AND p.`pincode`=a.`pincode`";
  $result1 = $db->query($query1);
   if(mysqli_num_rows($result1) > 0){
     //echo "failed to get:".$mysqli->error;
   	 while($row = mysqli_fetch_array($result1)){
?>

<img src="hlogo.png" align="center">
<table class="t1" align="center">
	
	
	<tr><th>Hospital ID &emsp;:</th><td>&emsp;<?php echo $row["HID"]; ?></td><br></tr>
     <tr><th>Hospital Name &emsp;:</th><td>&emsp;<?php echo $row["HName"]; ?></td><br></tr>
        <!--<tr><th>Email :</th><td class="email"><?php //echo $row["Street"]; ?></td><br></tr>-->
        
        <tr><th>Address &emsp;:</th><td>&emsp;<?php echo $row["Street"].","."\t".$row['Area'].","."\t"."<br>"."&emsp;".$row['City'].","."\t".$row['State']."\t"."-".$row['pincode']; ?></td></tr>
        <tr><th>Phone no &emsp;:</th><td>&emsp;<?php echo $row["phno"]; ?></td></tr>
</table>
<?php 
}
}
else 
	echo "failed to get:".$mysqli->error;
}
	 ?>
	

<style>
img{
  width: 300px;
  height: 250px;
  outline: none;
  border: 1px solid red;
  border-radius: 50%;
  margin-left: 250px;
}
table.t1{
line-height: 30px;
font-family: "rubik";
font-size: 20px;
margin-left: 200px;
background-color: black;
border:1px solid black;
border-radius: 20px;
opacity: 0.7;

}
table.t1 th{
  text-align: right;
  text-transform: capitalize;
  color: white;


}
  table.t1 td{
    text-align: left;
    text-transform: capitalize;
    color: #eaff00;
  }
</style>
 
 	