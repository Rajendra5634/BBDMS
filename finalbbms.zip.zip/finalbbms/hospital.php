<?php 

$db = mysqli_connect('localhost','root','','bbms');

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Hospital Login and Registration</title>
	<style>
		*{
			margin: 0px;
			padding: 0px;
			box-sizing: border-box;
			text-decoration: none;
		}
		body{

			background-image: url(hospital.jpg);
			background-repeat: no-repeat;
			color: black;
			background-size: cover;
		}
		.wrapper{
			background: transparent;
			width: 100%; 
			height: 800px;

		}
		.head{
			width: 30%;
			position: absolute;
		}
		.head h1{
			margin-top: 300px; 
		}
		.form{
			margin-left: 30%;
			width: 28%;
			position:absolute;
			height: 680px;
			background-color: white;
			opacity: 0.9;
			border-radius: 20px;
			padding: 20px;
		}

		form.f2{
			margin-top: 30px;
			padding-top: 20px;
		    margin-left: 60%;
			width: 20%;
			position:relative;
			height: 300px;
			background-color: white;
			opacity: 0.9;
			border-radius: 20px;
			padding: 20px;	
			padding-left: 40px;
			padding-bottom: 60px;
		}
		 input{
			width: 160px;
			margin: 10px 0;
			padding: 10px;
			background: transparent;
			border: 1px solid black;
			border-radius: 20px;
			outline: none;
			color: black;
			background-color: white;
			vertical-align: middle;
			font-family: 'Raleway', sans-serif;
		}
		p.h{
			text-align: center;
			font-size: 24px;
			font-style: italic;
			color: red;
			font-family: "rubik";
			margin-bottom: 10px;
			padding-bottom: 10px;
		}
		label{
			text-align: right;
			font-family: "rubik";
			font-size: 20px;
			padding-bottom: 10px;
		}
		::placeholder{
			color: black;
			text-align: center;
			font-family: "rubik";
			font-size: 16px;
			opacity: 0.7;
		}
		.button2,.button3{
			align-items: center;
			background: yellow;
			border: 2px solid yellow;
			border-radius: 20px;
			color: black;
			font-size: 19px;
			width: 150px;

			}
		.button2:hover{
			background: black;
			color: white;
			}
			.button3:hover{
			background: black;
			color: white;
			}
			h3{
				padding-top: 20px;
			}
			h3 a{
				font-family: arial;
				font-style: italic;
				font-size: 18px;
			
				color: red;
				padding-top: 30px;
			}
			h3 a:hover{
				color: green;

			}
	</style>
</head>
<body>
	<div class="wrapper">
		<div class="head">
			<h1>Hospital Registration & Login Form</h1>
			<h3><a href="frontpage.html">Go Back<a></h3>
		</div>
		<div class="form">
			<form action="#" method="post" autocomplete="off">
				<p class="h">REGISTRATION FORM</p><br>
				<label>Hospital ID:<br><input type="text" name="hid" class="hid" placeholder="Hospital ID" required></label><br>
			<label>Hospital name:<br><input type="text" name="hname" class="hname" placeholder="Hospital Name" required></label><br>
			<label>Password:<br><input type="password" name="p1" class="pwd" placeholder="Enter Password" required>
			<input type="password" name="p2" class="pwd" placeholder="Confirm Password" required></label><br>
			<label>Address:<br>
				<input type="street" name="street" class="street" placeholder="Street" required>
				<input type="area" name="area" class="area" placeholder="Area" required>
				<input type="city" name="city" class="city" placeholder="City" required>
				<input type="state" name="state" class="state" placeholder="State" required>
				<input type="number" name="pin" class="pin" placeholder="Pincode" required></label><br>
				<label>Phone no<br><input type="number" name="phone" class="phone" placeholder="Phone Number" required><br>
					<?php 
						if(isset($_POST['hid'])){
							$hid = $_POST['hid'];
							$name = $_POST['hname'];
							$p1 = $_POST['p1'];
							$p2 = $_POST['p2'];
							$street = $_POST['street'];
							$area = $_POST['area'];
							$city = $_POST['city'];
							$state = $_POST['state'];
							$pin = $_POST['pin'];
							$phone = $_POST['phone'];

						$q1 = "INSERT INTO haddress2 (pincode, city, state) 
  			   				SELECT '$pin','$city','$state' from haddress2 WHERE NOT EXISTS(SELECT 'pincode' from haddress2 where pincode='$pin') limit 1";
  			   			//$r1 = mysqli_query($q1);

  			   			$q2 = "INSERT INTO haddress1 VALUES('$hid', '$street', '$area', '$pin')";
  			   			//$r2 = mysqli_query($q2);
						
						$query = "INSERT INTO hospital VALUES('$hid','$name','$p1','$phone')";
						//$result = mysqli_query($db,$query);
						if($p1==$p2){
							if($db->query($q1)==true){
							if(($db->query($query)==true)&&($db->query($q2)==true))
								echo"<script type='text/javascript'> alert('Registered Successfully')</script>";
							else
								echo "<script type='text/javascript'> alert('Hospital ID Already Exists')</script>";
						}
					}
						else
							echo "<script type='text/javascript'> alert('Wrong Password Combination')</script>";
					
						}
						else
							echo $db->error;
					?>
				<input type="submit" name="register" value="Register" class="button3">
			</form>	
		</div>
		<div class="form1">
			<form class="f2" autocomplete="off" method="post" action="#">
			<p class="h">LOGIN FORM</p>
			<label>Hospital ID:<br><input type="text" name="hosid" class="hid" placeholder="Hospital ID" required></label><br>
			<label>Password:<br><input type="password" name="pwd" class="pwd" placeholder="Enter Password" required></label><br>
			<?php 
				session_start();
				if(isset($_POST['hosid'])){
					$hosid = $_POST['hosid'];
					$pwd = $_POST['pwd'];

					$query1 = "SELECT * FROM hospital WHERE HID='$hosid' AND password='$pwd'";
					$results1 = mysqli_query($db, $query1);
					if(mysqli_num_rows($results1) > 0){
						$_SESSION['hosid'] = $hosid;
					
					if($_SESSION['hosid'] == $hosid){
      					$_SESSION['success'] = "You are now logged in";
      					echo"<script type='text/javascript'> alert('Logged in Successfully')</script>";
      					header('location: hospital-control.php');
    				}
    			}
    			else
    				echo "<script type='text/javascript'> alert('Wrong username/password')</script>";
				}
			 ?>
			<input type="submit" name="login1" value="Login" class="button2">
		</div>
	</div>

</body>
</html>