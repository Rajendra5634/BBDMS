<?php 

if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


$db = mysqli_connect('localhost','root','','bbms');

 ?>
 <form class="pass" action="#" method="post" autocomplete="off" align="center">
 	<label class="change">Enter old Password / phone-no</label><br>
 	<input type="password" name="old" class="pwd" placeholder="old password / ph-no" required><br>
 	<label class="change">enter new password</label><br>
 	<input type="password" name="p1" class="pwd" placeholder="new password" required><br>
 	<label class="change">re-enter new password</label><br>
 	<input type="password" name="p2" class="pwd" placeholder="re-enter password" required><br>
 	<?php 

 if(isset($_POST['old'])){
 		$old = $_POST['old'];
 		$p1 = $_POST['p1'];
 		$p2 = $_POST['p2'];

 	$change = "SELECT * FROM blood_bank_manager WHERE `password` = '$old' OR email = '$old' AND MID = '$id'";
 	$rchange = mysqli_query($db,$change);
 	$ic = "UPDATE blood_bank_manager SET password = '$p1' WHERE MID = '$id'";
 	if($p1==$p2){
 		if(mysqli_num_rows($rchange) > 0){
 			$ric = mysqli_query($db,$ic);
 			echo "<h4><script type='text/javascript'> alert('Password Changed Successfully')</script></h4>";

 		}else
 		echo "<h4><script type='text/javascript'> alert('Invalid Password/Email/ph-no')</script></h4>";
 	}
 	else
 		echo "<h4><script type='text/javascript'> alert('Wrong password combination')</script></h4>";
 }
}
  ?>
 	<input type="submit" name="btn" value="change password" class="button">
 </form>

 

 <style>
 	h4{
 		text-transform: capitalize;
 		font-size: 16px;
 		color: pink;
 		margin-bottom: 0px;
 	}
 	.pass{
 		margin-top: 60px;
 		margin-left: 20px;
 		display: block;
 		width: 340px;
 		padding: 20px;
 		box-sizing: border-box;
 		border:2px solid green;
 		border-radius: 40px;
 		
 	}
 	.pwd{
 			width: 180px;
			padding: 2px;
			
			margin-bottom: 15px;
			background: transparent;
			border: 1px solid black;
			border-radius: 20px;
			outline: none;
			color: black;
			background-color: white;
			vertical-align: middle;
			font-size: 24px;
			text-align: center;
 	}
 	.change{
 		width: 300px;
 		text-align: center;
 		text-transform: capitalize;
 		font-family: "rubik";
 		font-size: 18px;
 		color: white;
 	}
 	.pwd::placeholder{
 		text-transform: capitalize;
 		font-size: 13px;
 		text-align: center;
 		color: black;
 	}
 	.button{
 		margin: 0px;
 		text-align: center;
 		text-transform: capitalize;
 		background-color: green;
 		color: white;
 		outline: none;
 		border:2px solid green;
 		border-radius: 20px;
 		padding: 10px;
 		font-size: 16px;
 		font-family: "rubik";
 	}
 	.button:hover{
 		background-color: black;
 		color: pink;
 	}

 </style>