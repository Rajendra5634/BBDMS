<?php 
if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


  $db = mysqli_connect('localhost','root','','bbms');
  ?>
  <form class="f1" action="#" method="post" align="center"  autocomplete="off">
    <input type="text"  name="mname1" class='mname' placeholder="first name" required>
    <input type="text"  name="mname2" class='mname' placeholder="last name"><br>
    <input type="text"  name="email" class='email1' placeholder="email" required="@gmail.com"><br>
    <input type="number"  name="phno" class='phno' placeholder="Phone no" required><br>
    <input type="submit" name="update" class="btn" value="UPDATE"><br>
    
          
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
      
      
    

  <?php
      if(isset($_POST['update'])){
        $name1 = $_POST['mname1']; 
        $name2 = $_POST['mname2']; 
        $email = $_POST['email']; 
        $phno = $_POST['phno']; 
        
      $uq3 = "UPDATE blood_bank_manager SET Fname = '$name1',Lname = '$name2', email = '$email',ph_no = '$phno' WHERE MID = '$id'";
      $ruq3 = mysqli_query($db,$uq3);
      if($ruq3)
        echo "<h6><script type='text/javascript'> alert('Updated Successfully')</script></h6>";
      
      else
        echo "<h6><script type='text/javascript'> alert('Not Updated Check Once Again')</script></h6>";
    }
    //echo $db->error();
  }

  ?>
</form>
         <style>
          h6{
            text-transform: capitalize;
            font-size: 20px;
            font-family: "rubik";
            color: pink;
            font-style: italic;
            margin-left: 10px;
            background-color: black;
            width: 200px;
          }
          .f1{
            width: 300px;
            margin-left: 50px;
            margin-top: 50px;
            padding: 40px;
            background-color: #606157;
            border: 2px solid white;
            border-radius: 20px;
          }
          .mname,.email1,.phno{
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            outline: none;
            border-bottom: 2px solid black;
            background-color: transparent;
            font-size: 16px;
            text-transform: uppercase;
            text-align: center;
            color: white;
          }
          .mname{
            width: 100px;
          }
          .email1{
            text-transform: none;
          }
          ::placeholder{
            opacity: 1;
            color: white;
            font-size: 14px;
            text-transform: uppercase;
          }
          .btn{
            border:2px solid black;
            background-color: transparent;
            color: black;
            background-color: yellow;
            border-radius: 30px ;
            padding: 10px;
          } 
          .btn:hover{
            background-color: red;
            color: white;
          }
         </style>          
          
