<?php 
	$db = mysqli_connect('localhost','root','','bbms');

 ?>
 <form class="searchform" autocomplete="off" action="#" method="post">
<label class="l1"><b>select blood group :</b></label>
	<select name="choose1" class="choose1" required>
	<option value="choose1"><i>choose blood group</i></option>
	<option value="A+">A+</option>
	<option value="A-">A-</option>
	<option value="B+">B+</option>
	<option value="B-">B-</option>
	<option value="AB+">AB+</option>
	<option value="AB-">AB-</option>
	<option value="O+">O+</option>
	<option value="O-">O-</option>
	</select>
	<input type="submit" name="search" value="search" class="btn2"><br>
	<?php 
		if(isset($_POST['search'])){
			$blood = $_POST['choose1'];
			if($blood == 'choose1'){
				echo "<script>alert('To Find Select Blood Group')</script>";
			}
			else{
				//echo"<script>alert('welcome')</script>";
				$b1 = "SELECT b.`BBID`,`$blood`,Fname,Lname,Rphno FROM `blood_stock` a,`blood_bank` b,receptionist WHERE RBBID=b.`BBID` AND a.`BBID`=b.`BBID` order by b.`BBID` desc";
				$rb1 = mysqli_query($db,$b1);
				if(mysqli_num_rows($rb1)>0){
					?>
				</form>
					<table class="t2">
						<tr><th>Blood Bank ID</th><th>Available Stock For:  <?php echo $blood; ?></th><th>Receptionist Name</th><th>Contact Number</th></tr>
					
					<?php
					while($row = mysqli_fetch_array($rb1)){
						$bid = $row['BBID'];
						$grop = $row[$blood];
						$fname = $row['Fname'];
						$lname = $row['Lname'];
						$ph = $row['Rphno'];
						if($grop > 0){
							echo"<tr><td>".$bid."</td><td>".$grop."</td><td>".$fname.' '.$lname."</td><td>".$ph."</td></tr>";
						}
						//else
							//echo "<h3>0 results</h3>";

					}
				}
				else
					echo "<script>alert('NO Stock Currently Available')</script>";
			}
		}
	 ?>
</table>

<style type="text/css">
	.t2{
		width: 80%;
		text-align: center;
		text-transform: capitalize;
		outline: none;
		border:none;
		border-radius: 0px 20px  0px 20px;
		margin-left: 5%;
		margin-top: 5%;
		margin-bottom: 10%;
	}
	.t2 th{
		width:150px;
		background-color: black;
		padding: 5px;
		color: red;
		font-size: 18px;
		font-family: "rubik";
		border-collapse: collapse;
	}
	
	.t2 td{
		background-color: black;
		color: white;
		border:none;
		padding: 5px;
	}
	
	h3{
		text-transform: capitalize;
	}
 	.searchform{
 		margin-left: 30px;
 		margin-top: 60px;
 		display: block;
 		
 		border-radius: 20px;
 		width: 470px;
 		padding: 15px;
 		
 		background-color: grey;
 		opacity: 1;
 		color: black;
 	}
 	.l1{
 		text-align: right;
 		text-transform: capitalize;
 		padding: 5px;
 		color: black;
 		font-family: "rubik";
 		font-size: 18px;
 	}
 	
 	.choose1{
 		padding: 5px;
 		width: 170px;
 		font-size: 14px;
 		text-align: center;
 		outline: none;
 		border: 1px solid black;
 		border-radius: 20px;
 		align-content: right;
 	}
 	.btn2{
 		margin-top: 10px;
 		margin-left: 0px;
 		width: 100px;
 		padding: 5px;
 		text-align: center;
 		font-size: 16px;
 		border:1px solid black;
 		border-radius: 20px;
 		outline: none;
 		
 		background-color: black;
 		font-weight: bold;
 		color: red;
 		text-transform: uppercase;
 		font-style: bold;
 	}
 	
 </style>