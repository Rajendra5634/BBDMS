<?php 
 //intialising variables
$name='';
$DID='';
$dob='';
$gender='';
$phno='';
$address='';
$R_DID='';
//establishing connection
$db = mysqli_connect('localhost', 'Amith', 'Amith#06', 'bbms');
	echo 'connected succssfully';
if(isset($_POST['submit'])){
	$DID = $_POST['did'];
	$R_DID = $_POST['rdid'];
	$name = $_POST['username'];
	$dob = $_POST['dob'];
	$gender = $_POST['gender'];
	$phno = $_POST['phno'];
	$address = $_POST['address'];

	//inserting the entered values to database
  	$query = "INSERT INTO donor VALUES('$DID','$name','$dob', '$gender', '$address', '$phno', '$R_DID')";
  	//mysqli_query($db,$query);
  	//mysqli_execute($db,$query);
  	if($db->query($query)==true)
  	echo'record inserted succssfully';
   else
   	echo'error:'.$query.'<br>'.$db->error;
  	
  
  }
 $db->close();
 
 ?>