<?php
$servername = "localhost";
$username = "root"; // For MYSQL the predifined username is root
$password = ""; // For MYSQL the predifined password is " "(blank)
$db="bbms";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

 
// Check connection

 if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully";
$query='select blood_id,blood_group from blood_details';
$result=$conn->query($query);
if ($result->num_rows>0) {
	while ($row =$result->fetch_assoc()) {
		echo "id:".$row['blood_id']."group:".$row['blood_group']."<br>";
	}
}else{
	echo "0 results";
}
$conn->close();
?>