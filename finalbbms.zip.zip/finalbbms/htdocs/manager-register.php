<?php 
 //intialising variables
$fname='';
$lname='';
$MID='';
$email='';
$phno='';

//establishing connection
$db = mysqli_connect('localhost', 'Amith', 'Amith#06', 'bbms');
	echo 'connected succssfully';
if(isset($_POST['submit'])){
	$MID = $_POST['mid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];

	//inserting the entered values to database
  	$query = "INSERT INTO blood_bank_manager(MID,Fname,Lname,email,ph_no) VALUES('$MID','$fname', '$lname', '$email', '$phno')";
  	//mysqli_query($db,$query);
  	//mysqli_execute($db,$query);
  	if($db->query($query)==true)
  	echo'record inserted succssfully';
  $query1= "SELECT fname FROM blood_bank_manager";
  $query2= "SELECT lname FROM blood_bank_manager";
  if (($db->query($query1)==true) &&($db->query($query2)==true)) {
	  	
	  	echo $query1,$query2;
  }
  
   else
   	echo'error:'.$query.'<br>'.$db->error;
  	$db->close();
  
  }
 
 
 ?>