<?php
include "connection.php";
?>
<style>
.form{
	margin-top:25px;
	margin-left:200px;
}
.form label{
	 margin-top:20px;
	 text-weight:bold;
  padding: 10px;
  border-radius: 5px;
  color: #abaacd;
  font-weight: 700;
  text-transform: uppercase;
}
.form label input{
	background:#212131;
	color:#fff;
}
</style>
<form class="form" action="#" method="post" autocomplete="off">
<label>Donor-ID:<input type="text" name="did" class="did" placeholder="Donor-ID"required></label><br><br>
<label>UserName:<input type="text" name="fname" class="username" placeholder="first name"required>
				<input type="text" name="lname" class="username" placeholder="last name"required></label><br><br>
<label>Date-of-Birth:<input type="date" name="dob" class="dob" placeholder="eg:dd/mm/yyyy"required></label>
<br><br><label>Gender:<label><input type="radio" id="other" class="radio" name="gender" value="other" required>Others</label>
 	<label><input type="radio" id="female" class="radio" name="gender" value="female" required>Female</label>
 	<label><input type="radio" id="male" class="radio" name="gender" value="male" required>Male</label></label><br><br>
<label>Phone-no:<br><input type="number" name="phno" class="phoneno" placeholder="eg:1234567890"required></label><br><br>
<label>Address:<br><input type="text" name="house_no" class="address" placeholder="House no"required><br>
					<input type="text" name="street" class="address" placeholder="Street"required><br>
					<input type="text" name="area" class="address" placeholder="Area"required><br>
					<input type="text" name="city" class="address" placeholder="City"required><br>
					<input type="text" name="state" class="address" placeholder="State"required><br>
					<input type="number" name="pincode" class="address" placeholder="pincode"required></label><br><br>
<?php 
if(isset($_POST['did'])){
	$DID = $_POST['did'];
	$R_DID = $_POST['rdid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$dob = $_POST['dob'];
	$gender = $_POST['gender'];
	$phno = $_POST['phno'];
	$house_no = $_POST['house_no'];
	$street = $_POST['street'];
	$area = $_POST['area'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$pincode = $_POST['pincode'];

	//inserting the entered values to database
  	$query = "INSERT INTO donor VALUES('$DID','$fname','$lname','$dob', '$gender', '$phno', '$R_DID')";
  	$query1 = "INSERT INTO d_pincode (pincode, city, state) 
  			   SELECT '$pincode','$city','$state' from d_pincode WHERE NOT EXISTS(SELECT 'pincode' from d_pincode where pincode='$pincode') limit 1";

  	$query2 = "INSERT INTO address VALUES('$DID', '$house_no', '$street', '$area', '$pincode')";
  	//mysqli_query($db,$query);
  	//mysqli_execute($db,$query);
	if(($conn->query($query1)==true)){
  	if(($conn->query($query)==true)&&($conn->query($query2)==true))
  		
  	
  	echo'record inserted succssfully';
   else
   	echo'Check Donor-ID correctly';
}
  	else
  	echo'error:'.$query.'<br>'.$conn->error;
  }
 $conn->close();
 ?>
<input type="submit" name="submit" class="button" value="ADD">
</form>