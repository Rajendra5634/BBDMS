<?php
include "connection.php";
?>
<style>
.D2{
	text-align:center;
	border-collapse:collapse;
	margin:25px 0;
	font-size:0.9em;
	min-width:400px;
	margin-left:200px;
	font-weight:bold;
}
.D2 th{
	color:#fff;
	text-align:left;
	font-weight:bold;	
}
.D2 td{
	padding:12px 15px;
	color:#009879;
	border-bottom:1px;
}
</style>
<table class="D2">
<?php
$qr='select Fname,Lname,D_date,Amount,code from donor,blood where DID = B_DID';
$result=$conn->query($qr);
if ($result->num_rows>0) 
{
    echo"<tr><th>Fname</th><th>Lname</th><th>D_date</th><th>Amount</th><th>code</th></tr>";
	// output data of each row
    while($row=$result->fetch_assoc()) 
	{
        echo "<tr><td>".$row["Fname"]."</td><td>".$row["Lname"]."</td><td>".$row["D_date"]."</td><td>".$row["Amount"]."</td><td>".$row["code"]."</td></tr>";
    }
    
?>
</table>
</div>
<?php
}
else
{
    echo "<tr><td>0 results</td></tr>";
}
$conn->close();
?>