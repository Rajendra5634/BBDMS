<?php 
include "connection.php";
//if($_SESSION['hosid'] == true){
  //  $id= $_SESSION['hosid'];
  //$_SESSION['success'] = "You are now logged in";


  //$db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  ?>
  <form class="f1" action="#" method="post" align="center"  autocomplete="off">
    <input type="text"  name="hname" class='hname' placeholder="Hospital name" required><br>
    <input type="text"  name="street" class='street' placeholder="Street" required><br>
    <input type="text"  name="area" class='hname' placeholder="Area" required><br>
    <input type="text"  name="city" class='city' placeholder="City" required><br>
    <input type="text"  name="state" class='state' placeholder="State" required><br>
    <input type="number"  name="pincode" class='pincode' placeholder="Pincode" required><br>
    <input type="number"  name="phno" class='phno' placeholder="Phone no" required><br>
    <input type="submit" name="update" class="btn" value="UPDATE"><br>
    
          
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
      
      
    

  <?php
      if(isset($_POST['hname'])){
        $name = $_POST['hname']; 
        $street = $_POST['street']; 
        $area = $_POST['area']; 
        $city = $_POST['city']; 
        $state = $_POST['state']; 
        $pincode = $_POST['pincode']; 
        $phno = $_POST['phno']; 
        
      
   /*   $up = "SELECT * FROM hpincode WHERE pincode = '$pincode'";
      $uq1 = "UPDATE hospital SET HName = '$name', phno = '$phno' WHERE HID = '$id'";
      $up4 ="INSERT into hpincode VALUES('$pincode','$city','$state')";
      $up2 = "UPDATE hpincode SET  city = '$city', state = '$state' WHERE pincode = '$pincode'";
      $uq3 = "UPDATE haddress1 SET Street = '$street', area = '$area', pincode = '$pincode' WHERE HID = '$id'";
      */
      $rup = mysqli_query($conn,$up);
     // $ruq1 = mysqli_query($db,$uq1);
    
      /*if($ruq1){
        if(mysqli_num_rows($rup) > 0)
          $rup42 = mysqli_query($db,$up2);
        
        else
          $rup42 = mysqli_query($db,$up4);
      
      if($rup42){
        $ruq3 = mysqli_query($db,$uq3);
        echo "<h6>updated successfully</h6>";
      }
      else
        echo "<h6>Not Updated Check Once Again</h6>";
    }
    //echo $db->error();
  }
*/}
  ?>
</form>
         <style>
          h6{
            text-transform: capitalize;
            font-size: 20px;
            font-family: "rubik";
            color: pink;
            font-style: italic;
          }
          .f1{
            width: 250px;
            margin-left: 350px;
            padding: 20px;
          }
          .hname,.street,.city,.area,.state,.pincode,.phno{
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            outline: none;
            border-bottom: 2px solid black;
            background-color: transparent;
            font-size: 16px;
            text-transform: uppercase;
            text-align: center;
            color: white;
          }
          ::placeholder{
            opacity: 1;
            color: black;
            font-size: 14px;
          }
          .btn{
            border:2px solid black;
            background-color: transparent;
            color: black;
            background-color: yellow;
            border-radius: 30px ;
            padding: 10px;
          } 
          .btn:hover{
            background-color: red;
            color: white;
          }
         </style>          
          
