<?php
include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>home/manager login</title>
<link rel="stylesheet" href="Manager_login-style.css">
<link href="http://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
<style type="text/css">
  *{
margin: 0;
padding: 0;
box-sizing: border-box;
text-decoration: none;
}
body{

font-family: 'Raleway', sans-serif;
background-image: url(manager.jpg);
background-repeat: no-repeat;
background-size: cover;
}
.background{
background-image: url(manager.jpg); 
margin: 0px;
padding-bottom: 8%;
background-size: cover;
background-position: center;
width: 100%;
display: flex;
}
.text, .box{
margin-top: 45vh;
}
.login{
margin-left: 10%;
font-weight: 300px;
}
.box{
margin-top: 210px;
margin-left: 9%;
flex: 1;
}
.text h1{
font-size: 70px;
color: black;
font-weight: 500;
text-align: center;
}
.text p{
font-size: 20px;
color: black;
font-weight: 300;
font-style: bold;
padding-bottom: 70px;
}
.text p a{
color: #fff;
font-weight: 700;
}
.text p a:hover{
  color: red;
}

.text p i{
  margin: 0px;
  padding: 0px;
  color:yellow;
  font-style: italic;
  font-size: 16px;
}
.form{
background: white;
color: black;
display: flex;
flex-direction: column;
width: 250px;
opacity: 0.9;
border-radius: 20px;
padding-left: 20px;
}
img{
  border-image: white;
  margin: 0px;
  width: 70px;
  height: 60px;
  align-items: center;
}
label{
  margin:10px 5px;
  padding: 0px;
  float: right;
  font-size: 20px;
  font-family: times new roman;
  font-style: bold italic;
  flex-direction: absolute;
  color: black;
}
input{
float: left;
margin: 5px 0;
padding: 10px;
background: transparent;
color: black;
border: none;
outline: none;
font-family: arial, sans-serif;
}

.username, .password{
  float: left;
  border: 2px solid black;
  
  border-radius: 20px;

}
.button{
background: black;
border: 2px solid white;
color: white;
border-radius: 20px;
font-size: 19px;
width: 150px;

}
.button:hover{
background: yellow;
color: #000;
}
</style>
</head>
<body>
<main>
<div class="background">
<div class="text">
<h1>Manager Login</h1>
<p><b>No Account?</b><a href="Manager_Signup.html">Sign Up</a> or <a href="frontpage.html">Go Back To Home</a></p>
<P><i><b>Note:</b> You must Register as Manager before Login</i></P>
</div>
<div class="box">
<form class="form" method="POST" action="#" autocomplete="off">
  <img src="user-logo.png" align="center">
  <label>Manager ID:<input type="text" name="id" class="username" placeholder="manager id"required></label>
<label>Password:<input type="password" name="password" class="password" placeholder="password"required></label>
<?php 
if (isset($_POST['id'])) {
  $id = $_POST['id'];
  $password = $_POST['password'];
  
    //$password = md5($password);
    $query = "SELECT * FROM blood_bank_manager WHERE MID='$id' AND password='$password'";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['id'] = $id;
      if($_SESSION['id'] = $id)
      {
      $_SESSION['success'] = "You are now logged in";
      echo"you are logged in";
      header('location: manager_control_panel.php');
      }
    }
  else {
      echo"<p>Wrong username/password combination</p>";
       }
}
 ?>
<input type="submit" name="login" class="button" value="login">
</form>
</div>
</div>
</main>
</body>
</html>