<?php
$servername = "localhost";
$username = "root"; // For MYSQL the predifined username is root
$password = ""; // For MYSQL the predifined password is " "(blank)
$db="bbms";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection

 if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully";
$query='select * from blood';
$result=$conn->query($query);
if ($result->num_rows>0) {
	while ($row =$result->fetch_assoc()) {
		echo "Amount:".$row['Amount']."BBID:".$row['BBID']."blood_type:".$row['Blood_type']."B_DiD:".$row['B_DiD']."Code:".$row['code']."D_date:".$row['D_date']."<br>";
	}
}else{
	echo "</br>0 results";
}
$conn->close();
?>
