<?php 
include "connection.php";
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


  //$db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  ?>
  <form class="f1" action="#" method="post" align="center"  autocomplete="off">
  	<label>Donor ID   :    <?php echo $_SESSION['id'];?></label><br>
    <input type="text"  name="Fname" class="Fname" placeholder="Donor First name" required><br>
    <input type="text"  name="Lname" class="Lname" placeholder="Donor Last name" required><br>
   <input type="date" name="DOB" class="DOB" placeholder="eg:dd/mm/yyyy" required><br>
 <input type="text" name="Gender" class="Gender"  placeholder="gender" required><br>  
  <input type="text" name="R_DID" class="R_DID" placeholder="Receptionist-ID" required><br>
  <input type="number"  name="ph_no" class="ph_no" placeholder="Phone no" required><br>
    <input type="submit" name="update" class="btn" value="UPDATE"><br>
    
          
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
      
      
    

  <?php
      if(isset($_POST['update']))
	  {
		
       $qr="UPDATE donor SET Fname='$_POST[Fname]',Lname='$_POST[Lname]',DOB='$_POST[DOB]',Gender='$_POST[Gender]',R_DID='$_POST[R_DID]',ph_no='$_POST[ph_no]' WHERE DID='$id'";    
      $rup=mysqli_query($conn,$qr);
	  if($rup){
		echo '<script type="text/javascript"> alert("Updated successfully")</script>';
      }
	  else
       echo '<script type="text/javascript"> alert("Not Updated Check Once Again")</script>';
	  }	
	  }
else		
 echo $conn->error();
  ?>
</form>
         <style>
          h6{
            text-transform: capitalize;
            font-size: 20px;
            font-family: "rubik";
            color: pink;
            font-style: italic;
          }
          .f1{
            width: 300px;
			height:300px;
            margin-left: 320px;
            padding: 20px;
          }
          .Fname,.Lname, .Gender, .DOB,.R_DID,.ph_no{
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            outline: none;
            border-bottom: 2px solid black;
            background-color: transparent;
            font-size: 16px;
           
            text-align: center;
            color: white;
          }
          ::placeholder{
            opacity: 1;
            color: white;
            font-size: 14px;
          }
          .btn{
            border:2px solid white;
            background-color: transparent;
            color: black;
            background-color: yellow;
            border-radius: 30px ;
            padding: 10px;
          } 
          .btn:hover{
            background-color: red;
            color: white;
          }
         </style>          
          
