<?php 
	$db = mysqli_connect('localhost','root','','bbms');
	

 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>manager control panel</title>
	
<style type="text/css">
	*{
		margin: 0px;
		padding: 0px;
		list-style: none;
		text-decoration: none;
	}
	body{
		color: black;
		font-family: "Roboto",sans-serif;
	}
	.sidebar{
		position: absolute;
		left: -250px;
		width: 250px;
		height: 100%;
		background: black;
		transition: all .5s ease;
	}
	::-webkit-scrollbar{
		width: 25px;
	}
	::-webkit-scrollbar-track{
		border:7px solid black;
		box-shadow: inset 0 0 2.5px 2px rgba(0,0,0,0.5);
	}
	::-webkit-scrollbar-thumb{
		background: linear-gradient(
			45deg,
			#06dee1,
			#79ff6c
			);
		border-radius: 5px;
	}
	.sidebar header{
		color:white;
		font-size: 22px;
		text-align: center;
		line-height: 70px;
		background: #063146;
		user-select: none;
	}
	.sidebar ul a{
		display: block;
		height: 100%;
		width: 100%;
		line-height: 50px;
		font-size: 20px;
		color: white;
		padding-left: 40px;
		box-sizing: border-box;
		border-top: 1px solid rgba(255,255,255,-1);
		border-bottom: 1px solid grey;
		transition: .4s;
	}
	ul li:hover a{
		padding-left: 50px;
	}
	.sidebar ul a i{
		margin-right: 16px;
	}
	#check{
		display: none;
	}
	label #btn,label #cancel{
		position: absolute;
		cursor: pointer;
		background: #042331;
		border-radius: 3px;
	}
	label #btn{
		left: 40px;
		top: 25px;
		font-size: 35px;
		color: white;
		padding: 6px 12px;
		transition: all .5s;
	}
	label #cancel{
		z-index: 1111;
		left:-195px;
		top: 17px;
		font-size: 30px;
		color: #0a5275;
		padding: 4px 9px;
		transition: all .5s ease;
	}
	#check:checked ~ .sidebar{
		left: 0;
	}
	#check:checked ~ label #btn{
		left: 250px;
		opacity: 0;
		pointer-events: none;
	}
	#check:checked ~ label #cancel{
		left: 195px;
	}
	#check:checked ~ section{
		margin-left: 250px; 
	}
	section{
		background: url("bb1.jpg");
		background-position: center;
		background-size: cover;
		height: 100vh;
		transition: all .5s;
	}

</style>
</head>
<body>
	<input type="checkbox" id="check">
	<label for="check">
		<i class="fa fa-bars" id="btn"></i>
		<i class="fa fa-times" id="cancel"></i>
	</label>
	<div class="sidebar" id="sidebar">
		<header>Welcome</header>
			<ul>
				<li><a href="#"><i class="fa fa-times"></i>Home</a></li>
				<li><a href="#"><i class="fa fa-qrcode"></i>Profile</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Blood Donors</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Blood Groups</a></li>
				<li><a href="#"><i class="fa fa-link"></i>Add BloodBank</a></li>
				<li><a href="#"><i class="fa fa-link"></i>Add Receptionist</a></li>
				<li><a href="#"><i class="fa fa-link"></i>Add BloodGroup</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Stock List</a></li>
				<li><a href="#"><i class="fa fa-list"></i>Orders</a></li>
				<li><a href="#"><i class="fa fa-times"></i>logout</a></li>
			</ul>
	</div>
	<section></section>
</body>
</html>