<?php 
include "connection.php";
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


  //$db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  ?>
  <form class="f1" action="#" method="post" align="center"  autocomplete="off">
  	<label>Receptionist ID   :    <?php echo $_SESSION['id'];?></label><br>
    <input type="text"  name="Fname" class="fname" placeholder="First name" required><br>
    <input type="text"  name="Lname" class="lname" placeholder="Last name" required><br>
   <input type="date" name="Email" class="email" placeholder="Email" required><br>
 <input type="text" class="password" name="password" placeholder="password" required><br>  
  <input type="text" name="RBBID" class="rbbid" placeholder="Receptionist-BBID"><br>
  <input type="number"  name="Rphno" class="rphno" placeholder="Phone no" required><br>
    <input type="submit" name="update" class="btn" value="UPDATE"><br>
    
          
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
  <?php
      if(isset($_POST['update']))
	  {
		
       $qr= "UPDATE receptionist SET Fname ='$_POST[Fname]',Lname='$_POST[Lname]',Email='$_POST[Email]',password='$_POST[password]',RBBID='$_POST[RBBID]',Rphno='$_POST[Rphno]' WHERE RID='$id'";
      $rup=mysqli_query($conn,$qr)or die(mysqli_error());
	  if($rup)
	  {
		echo '<script type="text/javascript"> alert("Updated successfully")</script>';
      }
	  else
       echo '<script type="text/javascript"> alert("Not Updated Check Once Again")</script>';
	  }	
	  }
else		
 echo $conn->error();
  ?>
</form>
         <style>
          h6{
            text-transform: capitalize;
            font-size: 20px;
            font-family: "rubik";
            color: pink;
            font-style: italic;
          }
          .f1{
            width: 300px;
			height:300px;
            margin-left: 320px;
            padding: 20px;
          }
          .fname,.lname, .email, .password,.rbbid,.rphno{
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            outline: none;
            border-bottom: 2px solid black;
            background-color: transparent;
            font-size: 16px;
           
            text-align: center;
            color: white;
          }
          ::placeholder{
            opacity: 1;
            color: white;
            font-size: 14px;
          }
          .btn{
            border:2px solid white;
            background-color: transparent;
            color: black;
            background-color: yellow;
            border-radius: 30px ;
            padding: 10px;
          } 
          .btn:hover{
            background-color: red;
            color: white;
          }
         </style>          
          
