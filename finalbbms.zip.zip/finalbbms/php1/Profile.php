		<?php
$servername="localhost";
$username="root";
$password="";
$dbname="bbms";
// Create connection
$conn=new mysqli($servername,$username,$password,$dbname);
// Check connection
 if ($conn->connect_error){

    die("Connection failed:".$conn->connect_error);
}
?>
<div id="t1">
<table>
<?php
$qr='select DID,Fname,Lname,DOB,Gender,ph_no,R_DID from donor where DID="d001"';
$result=$conn->query($qr);
if ($result->num_rows>0) 
{
    // output data of each row
    while($row=$result->fetch_assoc()) 
	{
echo "<tr><td>DID:".$row["DID"]."</td></tr>";
echo "<tr><td>Fname:".$row["Fname"]."</td></tr>";
echo "<tr><td>Lname:".$row["Lname"]."</td></tr>";
echo "<tr><td>DOB:".$row["DOB"]."</td></tr>";
echo "<tr><td>Gender:".$row["Gender"]."</td></tr>";
echo "<tr><td>ph_no:".$row["ph_no"]."</td></tr>";
echo "<tr><td>D_RID:".$row["R_DID"]."</td></tr>";
    }  
?>
</table>
</div>
<?php
}
else
{
    echo "0 results";
}
$conn->close();
?>