<?php 
 
//establishing connection
$db = mysqli_connect('localhost', 'Amith', 'Amith#06', 'bbms');
 
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>signup Receptionist</title>

<link href="http://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
<style type="text/css">
	*{
margin: 0;
padding: 0;
box-sizing: border-box;
text-decoration: none;
}
body{
font-family: 'Raleway', sans-serif;
background: url(rep3.jpg);
background-repeat: no-repeat;
background-size: cover;
}
.background{
background-image: url(rep3.jpg); 
margin: 0px;
padding-bottom: 110px;
background-size: cover;
width: 100%;
display: flex;
padding-bottom: 20%;
}
.text, .box{
margin-top: 45vh;
}
.text{
margin-top: 20%;
margin-left: 0%;
max-height: 300px;
width: 200px;

}
.box{
margin-top: 13%;
padding-left: 38%;
flex: 1;
}
.text h1{

font-size: 70px;
color: black;
font-weight: 500;

}
.text p{
font-size: 20px;
color: black;
font-weight: 300;
}
.text p a{
color: #fff;
font-weight: 700;
}
.text p a:hover{
	color: red;
}
.form{
background: white;
color: black;
box-sizing: border-box;
display: flex;
flex-direction: column;
width: 450px;
opacity: 0.9;
padding-left: 20px;
border-radius: 20px;
font-family: times new roman;
}
img{
	border-image: white;
	margin: 0px;
	width: 70px;
	height: 60px;
	align-items: center;
	background-position: center;
}
label{
	margin:10px 5px;
	padding: 0px;
	float: right;
	font-size: 20px;
	font-family: times new roman;
	font-style: bold italic;
	flex-direction: absolute;
	color: black;
}

input{
margin: 10px 0;
padding: 10px;
background: transparent;
border: 1px solid black;
border-radius: 20px;
outline: none;
color: black;
background-color: white;
vertical-align: middle;
font-family: 'Raleway', sans-serif;
}
.rid, .rbid, .username, .dob, .phoneno,.password, .email{
border: 2px solid black;
border-radius: 20px;

}

::placeholder{
	color: black;
}
.button{
	align-items: center;
background: yellow;
border: 2px solid yellow;
border-radius: 20px;
color: black;
font-size: 19px;
width: 150px;
}
.button:hover{
background: black;
color: white;
}
</style>
</head>
<body>
<main>
<div class="background">
<div class="text">
<h1>ADD New Receptionist</h1>
<p><a href="frontpage.html">Go Back To Home</a></p>
</div>
<div class="box">
<form class="form" method="post" action="#" autocomplete="off">
	<img src="user-logo.png" align="center">
<label>Receptionist-ID:<br><input type="text" name="rid" class="rid" placeholder="Receptionist-ID"required></label>
<label>Blood-Bank-ID:<br><input type="text" name="rbid" class="rbid" placeholder="BloodBank-ID"required></label>
<label>Name:<br><input type="text" name="fname" class="username" placeholder="firstname"required>
				<input type="text" name="lname" class="username" placeholder="lastname"></label>
<label>Email:<br><input type="text" name="email" class="email" placeholder="eg:abc@gmail.com"required></label>
<label>Password:<br><input type="password" name="p1" class="password" placeholder="enter password"required>
				<input type="password" name="p2" class="password" placeholder="confirm password"></label>
<label>Phone-no:<br><input type="number" name="phno" class="phoneno" placeholder="eg:1234567890"required></label>
<?php 
if(isset($_POST['rid'])){
	$RID = $_POST['rid'];
	$R_BID = $_POST['rbid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$pass = $_POST['p1'];
	$pass1 = $_POST['p2'];
	$phno = $_POST['phno'];
	
if($pass==$pass1){
	//inserting the entered values to database
  	$query = "INSERT INTO receptionist VALUES('$RID','$fname','$lname','$email', '$pass', '$phno', '$R_BID')";
  	//mysqli_query($db,$query);
  	//mysqli_execute($db,$query);
  if($db->query($query)==true)
  	echo'record inserted succssfully';
   else
   	echo "RID/BBID/Email already exits";
   
}
else 
	echo"password does not matches";
  	
  }
 $db->close();
 ?>
<input type="submit" name="Register" class="button" value="Signup" align="center">
</form>
</div>
</div>
</main>
</body>
</html>