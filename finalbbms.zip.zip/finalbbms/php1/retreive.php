 <?php
require "manager-login.php";
include "connection.php"; 
session_start();
  if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
  } 
?>
<?php 
            $query1= "SELECT * from donor";
            $result1 = mysqli_query($db.$query1);
            if(mysqli_num_rows($r1) > 0){
              echo "failed to get:".$mysqli->error;
           ?>
           <table>
            <tr>
              <td>Donor ID</td>
              <td>Name</td>
              <td>DOB</td>
              <td>Gender</td>
              <td>Phone-No</td>
            </tr>
            <?php 
                $i=0;
                while($row = mysqli_fetch_array($r1)){
             ?>
             <tr>
               <td><?php echo $row["DID"]; ?></td>
               <td><?php echo $row["Fname"].$row["Lname"]; ?></td>
               <td><?php echo $row["DOB"]; ?></td>
               <td><?php echo $row["Gender"]; ?></td>
               <td><?php echo $row["ph_no"]; ?></td>
             </tr>
             <?php 
             $i++;
           }
              ?>
			  </table>
              <?php
              } 
              else{
                echo "failed to get:".$mysqli->error;
                echo "NO RESULTS FOUND";
              } 
              ?>