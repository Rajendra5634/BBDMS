<?php 
session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Receptionist</title>
	<style>
	@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap");
* {
  margin: 0;
  padding: 0;
  list-style: none;
  box-sizing: border-box;
  font-family: "Montserrat", sans-serif;
}

body {
	background-image:url(rep1.jpg);
  font-size: 14px;
  line-height: 24px;
}

.wrapper {
background-image:url(rep1.jpg);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 1360px;
  height: 670px;
  display: flex;
  border-radius: 15px;
  color:#fff;
}
 #313142;#212131;#393952;#313142;#5437b7; #abaacd;
.wrapper .wrapper_left {
  width: 300px;
  padding: 0 25px;
  display: flex;
  align-items: center;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
  box-shadow: 10px 0px 13px 0px rgba(41, 41, 57, 0.7);
}
.wrapper .wrapper_left ul li {
  margin-top: 40px;
  margin-bottom: 10px;
  border-radius: 3px;
  padding: 12px 25px;
  text-transform: uppercase;
  font-weight: 500;
  position: relative;
  overflow: hidden;
  width: 200px;
  letter-spacing: 2px;
  transition: all 0.4s ease;
  cursor: pointer;
}

.wrapper .wrapper_left ul li p {
  color:white;
  position: relative;
}

.wrapper .wrapper_left ul li:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background:black;
  background:(
    126deg,
    rgba(2, 0, 36, 1) 0%,
    rgba(123, 90, 231, 1) 0%,
    rgba(88, 54, 206, 1) 100%
  );
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transition: all 0.4s ease;
}

.wrapper .wrapper_left ul li.active {
  width: 200px;
}
.wrapper .wrapper_left ul li.active p {
  color: red;
}
.wrapper .wrapper_left ul li.active:before {
  width: 100%;
  transition: all 0.2s ease;
}

.wrapper .wrapper_left ul li:last-child {
  margin-bottom: 0;
}

.wrapper .wrapper_right {
  width: 1000px;
  padding: 30px 50px;
}

.wrapper .wrapper_right .title {
  font-size: 24px;
  text-align: center;
  font-weight: 700;
  color: #6b6b93;
  margin-bottom: 20px;
  text-transform: uppercase;
}

.wrapper .wrapper_right .item .item_info {
  display:inline;
  justify-content: space-around;
  align-items: left;
}
.wrapper .wrapper_right .item .item_info .img img{
  width: 150px;
  height: 150px;
  background: #fff;
  border-radius: 50%;
  margin-bottom: 20px;
  position: relative;
  margin-left:350px;
}
.wrapper .wrapper_right .item .item_info .img:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background:black;
  background: url("frames.png") no-repeat 0 0;
  width: 94px;
  height: 101px;
}

.wrapper .wrapper_right .item.Profile .item_info .img:before {
  background-position: 0 0;
  width: 94px;
  height: 101px;
}
.wrapper .wrapper_right .item.Add_donor .item_info .img:before {
  background-position: 0 -110px;
  width: 89px;
  height: 101px;
}
.wrapper .wrapper_right .item.update_details .item_info .img:before {
  background-position: 0 -220px;
  width: 100px;
  height: 100px;
}
.wrapper .wrapper_right .item.Donor_list .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.stock_list .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.logout .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item .item_info p {
  background:black;
  width: 150px;
  padding: 10px;
  border-radius: 5px;
  color: #abaacd;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
  margin-left:350px;
}
.wrapper .wrapper_right .item.Profile .item_info p {
  color: #dd0330;
}
.wrapper .wrapper_right .item.Add_donor .item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.update_details .item_info p {
  color: #61dafb;
}
.wrapper .wrapper_right .item.Donor_list .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.stock_list .item_info p {
  color: pink;
}

	</style>
</head>
<body>
<div class="wrapper">
  <div class="wrapper_left">
  <ul>
     <li data-li="Profile">
        <p>Profile</p>
      </li>
      <li data-li="Add_donor">
        <p>ADD DONOR</p>
      </li>
      <li data-li="update_details">
        <p>Update Profile</p>
      </li>
      <li data-li="Donor_list">
        <p>DONOR List</p>
      </li>
      <li data-li="stock_list">
        <p>Stock List</p>
      </li>
      <li data-li="logout">
        <p>Logout</p>
      </li>
    </ul>
  </div>
  <div class="wrapper_right">
    <div class="title">
	  Receptionist
    </div>
    <div class="container">
      <div class="item Profile" id="p">
        <div class="item_info">
          <div class="img"><img src="Rprofile.png"></div>
          <p>Profile</p>
        </div>
<?php include "Rprofile.php";?>
	 </div>
	 <div class="item Add_donor" style="display: none;">
        <div class="item_info">
          <p>Add Donor</p>
        </div>		
	<?php include "d-r.php";?>	
       </div>
      <div class="item update_details" style="display: none;">
        <div class="item_info">
          <p>Update Profile</p>
        </div>
		<?php include "Rupdetails.php";?>
       </div>
	   <div class="item Donor_list" style="display: none;">
        <div class="item_info">
          <p>Donor list</p>
        </div>
	<?php include "d1.php";?>	
       </div>
	   <div class="item stock_list" style="display: none;">
        <div class="item_info">
          <p>stock list</p>
        </div>
		<?php include "stock-list.php";?>
       </div>
	    <div class="item logout" style="display: none;">
        <div class="item_info">
          <p>logout:<a href="receptionist_login.php">yes</a></p>
        </div>
       </div>
  </div>
</div>
	<script>
var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "Profile") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Add_donor") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "update_details") {
      document.querySelector("." + li_value).style.display = "block";
    }  else if (li_value == "Donor_list") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "stock_list") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "logout") {
      document.querySelector("." + li_value).style.display = "block";
    } else {
      console.log("");
    }
  });
}
	</script>
</body>
</html>