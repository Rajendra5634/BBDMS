<?php
include "connection.php";
?>
<style> 
.D4{
	border-collapse:collapse;
	margin:25px 0;
	font-size:0.9em;
	min-width:400px;
	margin-left:200px;
	font-weight:bold;
}
.D4 th{
	background-color:black;
	color:#fff;
	text-align:center;
	font-weight:bold;	
}
.D4 td{
	text-align:left;
	padding:12px 15px;
	color:#009879;
	font-weight:bold;
}
</style>
<table class="D4">
<tr>
<th>DID</th>
<th>Fname</th>
<th>Lname</th>
<th>DOB</th>
<th>Gender</th>
<th>ph_no</th>
<th>R_DID</th>
</tr>
<?php
$qr="select * from donor";
$result=$conn->query($qr);
if ($result->num_rows>0) 
{
    // output data of each row
    while($row=$result->fetch_assoc()) 
	{
        echo "<tr><td>".$row["DID"]."</td><td>".$row["Fname"]."</td><td>".$row["Lname"]."</td><td>".$row["DOB"]."</td><td>".$row["Gender"]."</td><td>".$row["ph_no"]."</td><td>".$row["R_DID"]."</td></tr>";
    }
    echo"</table>";
?>
<?php
}
else
{
    echo "0 results";
}
$conn->close();
?>