<header id="main-header">
		<div class="container">
			
			<h1>BLOOD BANK AND DONOR MANAGEMENT SYSTEM</h1>	
		</div>
</header>
<style>
	#main-header{
	background-color: red;
	color:black; 
	text-align: center;
	width: 100%;
	margin-top: 0px;
	margin: 0px;
}
</style>