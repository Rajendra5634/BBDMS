<?php 
	$db = mysqli_connect('localhost','root','','bbms');
	$a = "SELECT orders FROM blood_bank WHERE BBID = '$bb'";
	$ra = mysqli_query($db,$a);
	if(mysqli_num_rows($ra)>0)
		while($row = mysqli_fetch_array($ra)){
			$order = $row['orders'];
		}
		if($order > 0){
			$up = "UPDATE blood_bank SET status = 'Available' WHERE BBID = '$bb'";
			$rup = mysqli_query($db,$up);
			echo "set to availability";
		}
		else
		{
			$up1 = "UPDATE blood_bank SET status = 'UnAvailable' WHERE BBID = '$bb'";
			$rup1 = mysqli_query($db,$up1);
			echo "set to unavailability";
		}
?>
