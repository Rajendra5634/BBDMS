<?php 
session_start();
if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";

  $db = mysqli_connect('localhost','root','','bbms');
  error_reporting(0);
    $order = $_GET['approve'];
    //echo "$order";
    
      $dq1 = "SELECT `BBID` from blood_bank Where BMID='$id'";
      $Rdq1 = mysqli_query($db,$dq1);
      if(mysqli_num_rows($Rdq1)>0){
        while($row=mysqli_fetch_array($Rdq1))
          $bbid = $row['BBID'];
        //echo "$bbid";
      $checkord = "SELECT `HID`,`HBBID`,`A+`,`A-`,`B+`,`B-`,`AB+`,`AB-`,`O+`,`O-`,SUM(`A+`+`A-`+`B+`+`B-`+`AB+`+`AB-`+`O+`+`O-`) AS torders FROM horders WHERE HID = '$order' AND HBBID = '$bbid'";
    
    $rcheckord = mysqli_query($db, $checkord);
    if(mysqli_num_rows($rcheckord)>0){
     while($row = mysqli_fetch_array($rcheckord)){
      $hid = $row['HID'];
      $bid = $row['HBBID'];
      $A1 = $row['A+'];
      $A2 = $row['A-'];
      $B1 =$row['B+'];
      $B2 =$row['B-'];
      $AB1 =$row['AB+'];
      $AB2 =$row['AB-'];
      $O1 =$row['O+'];
      $O2 =$row['O-'];
      $torders = $row['torders'];
      //echo "$A2".""."$B1";
     }
   }

      $check = "SELECT a.`BBID`,`A+`,`A-`,`B+`,`B-`,`AB+`,`AB-`,`O+`,`O-` FROM `blood_stock` a,`blood_bank` b WHERE a.`BBID` = '$bbid' and a.`BBID`=b.`BBID`";
      $rcheck = mysqli_query($db,$check);
    }
      if(mysqli_num_rows($rcheck)>0){
        while($row = mysqli_fetch_array($rcheck)){
      $bbid = $row['BBID'];
      $a1 = $row['A+'];
      $a2 = $row['A-'];
      $b1 =$row['B+'];
      $b2 =$row['B-'];
      $ab1 =$row['AB+'];
      $ab2 =$row['AB-'];
      $o1 =$row['O+'];
      $o2 =$row['O-'];
      //echo "$bbid";
     }
     if(($a1>=$A1) && ($a2>=$A2) && ($b1>=$B1) && ($b2>=$B2) && ($ab1>=$AB1) && ($ab2>=$AB2) && ($o1>=$O1) && ($o2>=$O2)){
                        $fetch = "UPDATE blood_bank SET orders = orders-'$torders' WHERE BBID = '$bbid'";
                         $minus = "UPDATE blood_stock SET `A+`=`A+`-'$A1',`A-`=`A-`-'$A2',`B+`=`B+`-'$B1',`B-`=`B-`-'$B1',`AB+`=`AB+`-'$AB1',`AB-`=`AB-`-'$AB2',`O+`=`O+`-'$O1',`O-`=`O-`-'$O2' where BBID = '$bbid'";
                         $rminus = mysqli_query($db,$minus); 
                         $rfetch = mysqli_query($db,$fetch);
                         $afaccept = "DELETE FROM horders WHERE HID='$hid' and HBBID='$bbid'";
                            $dr = mysqli_query($db,$afaccept);
                         if(($rminus) && ($rfetch)){
                          if($dr){
                            echo "<p><script type='text/javascript'> alert('Order AcceptedSuccessfully')</script></p>";
                            //header('location:manager.php');
                          }
                           else
                            echo "<script type='text/javascript'> alert('error: in Accept')</script>"; 
                          }
                }
     
   else{
    echo "<p><script type='text/javascript'> alert('Insufficient Stock To Accept')</script><p>";
    //header('manager.php');
}
    }
    else 
      echo "<p><script type='text/javascript'> alert('Does not have stock to accept')</script><p>";

    
   		}		
  ?>

    <style>
      
      p{
        margin-top: 200px;
        text-transform: uppercase;
        color: green;
        text-align: center;
        font-family: "rubik";
        font-size: 30px;
      }
    </style>