<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Hospital Login and Registration </title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<ul class="nav">
  <li onclick="showLogin()">Login</li>
  <li onclick="showSignup()">Sign up</li>
  
</ul>
<div class="wrapper">
  <div class="rec-prism">
   
    <div class="face face-front">
      <div class="content">
        <h2>Sign in</h2>
        <form onsubmit="event.preventDefault()" autocomplete="off">
          <div class="field-wrapper">
            <input type="text" name="username" placeholder="username">
            <label>username</label>
          </div>
          <div class="field-wrapper">
            <input type="password" name="password" placeholder="password" autocomplete="new-password">
            <label>password</label>
          </div>
          <div class="field-wrapper">
            <input type="submit" onclick="showThankYou()">
          </div>
          <span class="signup" onclick="showSignup()">Not a user?  Sign up</span>
        </form>
      </div>
    </div>
   
    <div class="face face-right">
      <div class="content">
        <h2>Sign up</h2>
        <form onsubmit="event.preventDefault()" autocomplete="off">
          <div class="field-wrapper">
            <input type="text" name="email" placeholder="email">
            <label>Hospital ID</label>
          </div>
          <div class="field-wrapper">
            <input type="text" name="email" placeholder="email">
            <label>Hospital Name</label>
          </div>
          <div class="field-wrapper">
            <input type="password" name="password" placeholder="password" autocomplete="new-password">
            <label>Password</label>
          </div>
          <div class="field-wrapper">
            <input type="password" name="password2" placeholder="password" autocomplete="new-password">
            <label>Re-enter Password</label>
          </div>
          <div class="field-wrapper">
            <input type="text" name="email" placeholder="email">
            <label>Phone no</label>
          </div>
          <div class="field-wrapper">
            <input type="submit" onclick="showThankYou()">
          </div>
          <span class="singin" onclick="showLogin()">Already a user?  Sign in</span>
        </form>
      </div>
    </div>
    
    <div class="face face-bottom">
      <div class="content">
        <div class="thank-you-msg">
          Thank you!
        </div>
      </div>
    </div>
  </div>
</div>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
