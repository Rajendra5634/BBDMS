<footer id="main-footer">
    	<p>Copyright &copy; 2020 Blood Bank Management System. <br>Design & Developed by Amith S & Ranjendra K N.<br>Dept of CSE BIT</p>
</footer>

<style>
	#main-footer{
		margin:0px;
	background: #333;
	color: white;
	text-align: center;
	
	padding-top: 5px;
	padding-bottom: 5px;
	margin-top: 500px;
	font-size: 18px;
	font-family: Times new roman;
	position: static;
}
</style>