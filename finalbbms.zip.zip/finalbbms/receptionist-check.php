<?php 
if($_SESSION['id']==true){
	$id=$_SESSION['id'];
$db = mysqli_connect('localhost','root','','bbms');
$q1 = "SELECT RID from receptionist, blood_bank,blood_bank_manager where R_BID=BBID and BMID=MID and MID='$id'";
$r1 = mysqli_query($db,$q1);
if (mysqli_num_rows($r1)==1){
	print_r($r1);
}
else
	echo"user already exists for this Blood Bank";
}
 ?>