<?php 

$db = mysqli_connect('localhost','root','','bbms');
?>
<form class="avail" autocomplete="off" action="#" method="post">
	<label class="l1">Enter blood bank :</label>
	<input type="text" name="id1" class="id1" required><br>
	<label class="l1">select blood group :</label>
	<select name="choose" class="choose" required>
	<option value="choose">choose blood group</option>
	<option value="A+">A+</option>
	<option value="A-">A-</option>
	<option value="B+">B+</option>
	<option value="B-">B-</option>
	<option value="AB+">AB+</option>
	<option value="AB-">AB-</option>
	<option value="O+">O+</option>
	<option value="O-">O-</option>
	</select><br>
	<input type="submit" name="sub" value="submit" class="btn3">
	
</form>
 <?php 
 	if(isset($_POST['id1'])){
 		$id1 = $_POST['id1'];
 		$choose = $_POST['choose'];
 		//echo $choose;
 		if($choose != 'choose'){
 		$stat = "SELECT `$choose` FROM blood_stock WHERE BBID='$id1'";
 		$rstat = mysqli_query($db,$stat);
 		if(mysqli_num_rows($rstat)>0){
 			while($row = mysqli_fetch_array($rstat)){
 				//echo $choose;
 				//echo $row[$choose];
 				if($row[$choose] > 0)
 					echo "<h4>Available Stock for ".$choose." is ".$row[$choose]."</h4>";
 				else
 					echo "<h4>Stock Unavailable for ".$choose." Group</h4>";
 		}
 	}
 	else 
 		echo "<h4><script type='text/javascript'> alert('Currently NO Stock Available in Given Blood Bank')</script></h4>";
 }
 else 
 	echo "<h4><script type='text/javascript'> alert('Select Blood Group')</script></h4>";
}
  ?>
 <style type="text/css">
 	.avail{
 		margin-left: 250px;
 		margin-top: 60px;
 		display: block;
 		border: 1px solid black;
 		border-radius: 20px;
 		width: 350px;
 		height: 160px; 
 		padding-top: 25px;
 		padding-left: 20px;
 		background-color: #606157;
 		opacity: 0.9;
 		color: black;
 	}
 	.l1{
 		text-align: right;
 		text-transform: capitalize;
 		padding: 5px;
 	}
 	.id1{
 		padding:5px;
 		width: 100px;
 		margin: 10px;
 		text-align: center;
 		font-size: 14px;
 		color: black; 
 		outline: none;
 		border: 1px solid black;
 		border-radius: 20px;
 		align-content: left;
 	}
 	.choose{
 		padding: 5px;
 		width: 100px;
 		font-size: 14px;
 		text-align: center;
 		outline: none;
 		border: 1px solid black;
 		border-radius: 20px;
 		align-content: right;
 	}
 	.btn3{
 		margin-top: 10px;
 		margin-left: 0px;
 		width: 100px;
 		padding: 5px;
 		text-align: center;
 		font-size: 16px;
 		border:1px solid black;
 		border-radius: 20px;
 		outline: none;
 		vertical-align: 50px;
 		background-color: black;
 		color: red;
 		text-transform: uppercase;
 		font-style: bold;
 	}
 	h4{ 
 		margin-top: 30px;
 		margin-left: 270px;
 		background-color: black;
 		width: 300px;
 		padding: 10px;
 		color: red;
 		font-size: 18px;
 		border: 1px solid red;
 		border-radius: 10px;
 		text-align: center;
 	}
 </style>