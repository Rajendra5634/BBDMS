<?php 

  if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
  
 $db = mysqli_connect('localhost','root','','bbms');

 $bank = "SELECT * FROM blood_bank,blood_bank_manager WHERE BMID=MID AND BMID = '$id'";
 $rbank = mysqli_query($db,$bank);
 if((mysqli_num_rows($rbank)) > 0){ 
 	echo "<h>present blood bank details are:</h>";
?>
<table class="t6">
	<tr>
		<th class="t6">Blood Bank ID</th>
		<th class="t6">Total orders</th>
		<th class="t6">Status</th>
	</tr>
	<?php 
		while ($row = mysqli_fetch_array($rbank)) {
	?>
	<tr>
		<td class="t6"><?php echo $row['BBID']; 
		$de = $row['BBID'];?></td>
		<?php if($row['orders'] > 0)
		echo "<td class='t6'>".$row['orders']."</td>";
		else
		echo"<td class='t6'>0</td>";
		?>
		<?php 
		echo "<td class='t6'>".$row['Status']."</td>";
		
		?>
	</tr>
	<?php
		}
	 ?>
</table>
<form method="post">
<input type="submit" value="Unregister" class="btn1" name="del"><br>
<?php 
	if(isset($_POST['del'])){
	$del = "UPDATE blood_bank SET BMID = NULL WHERE BBID = '$de'";
	$rdel = mysqli_query($db,$del);
	echo "<h>Unregistered Successfully</h>";
}
?>
</form>

<?php
 }
 else{
 	echo "<h>you not yet registered for any blood bank create one:</h>";
 	?>
 	<form class="blood_bank" method="post" action="#" autocomplete="off">
 		<label class="blood">Enter Blood Bank ID :</label>
 		<input type="text" name="bloodbank" class="bb" placeholder="blood bank id" required>
 		<input type="submit" name="btn1" class="but" value="create">
 		<?php 
 		if(isset($_POST['bloodbank'])){
 			$bb = $_POST['bloodbank'];

 			$bbq = "SELECT * FROM blood_bank WHERE BBID = '$bb'";
 			$bbi = "INSERT INTO blood_bank(BBID,orders,BMID) VALUES('$bb','0','$id')";
 			$bbu = "UPDATE blood_bank SET BMID = '$id' WHERE BBID = '$bb'";
 			$rbbq = mysqli_query($db,$bbq);
 			if(mysqli_num_rows($rbbq) > 0){
 				while($row = mysqli_fetch_array($rbbq))
 					$mid = $row['BMID'];
 				if($mid == NULL){
 					$rbbu = mysqli_query($db,$bbu);
 					echo "<h4>Blood Bank Registered Successfully</h4>";
 				}
 				else
 					echo "<h4>Not Created : Manager is Already Exists</h4>";
 			}
 			else{
 				$rbbi = mysqli_query($db,$bbi);
 				//include('blood_status.php');
 				echo "<h4>Blood Bank Created Successfully</h4>";
 			}
 			
 		} 

 		?>
 	</form>
 	<?php
 }
}
 ?>

 <style>
 	h{
 		font-family: times new roman;
 		font-size: 22px;
 		color: red;
 		background-color: black;
 		padding: 5px;
 		border-radius: 20px;
 		text-transform: capitalize;
 		text-align: center;
 		font-style: bold;
 	}
 	table.t6{
 		margin-top: 60px;
 		margin-left: 150px;
 		width:50%;
 		text-transform: uppercase;
 		display: block;
 		outline: none;
 		font-family: "rubik";
 		text-align: center;
 	}
 	table.t6 th.t6{
 		padding: 5px;
 		background-color: black;
 		color: cyan;
 		outline: none;
 		border: 1px solid black; 
 		border-radius: 10px 10px 10px 10px;
 	}
 	table.t6 td.t6{
 		background-color: white;
 		color: black;
 		font-size: 18px;
 		border-radius: 10px;
 		width: 150px;
 	}
 	.blood_bank{
 		margin-left: 150px;
 		margin-top: 60px;
 		padding: 10px;
 		font-family: "rubik";
 	}
 	label.blood{
 		text-transform: capitalize;
 		font-family: "rubik";
 		font-size: 20px;
 		font-style: bold;
 		color: white;
 		border-bottom: 2px solid cyan;
 		margin-right: 5px;
 	}
 	.bb{
 		border:1px solid white;
 		border-radius: 20px;
 		padding: 10px;
 		outline: none;
 		text-align: center;
 		font-size: 16px;
 		font-style: bold;
 		font-family: "rubik";
 	}
 	.bb::placeholder{
 		text-transform: capitalize;
 		color: black;
 	}
 	.but{
 		text-transform: uppercase;
 		text-align: center;
 		padding: 10px;
 		outline: none;
 		border:2px solid cyan;
 		border-radius: 20px;
 		background-color: black;
 		color: white;
 		font-family: "rubik";
 		font-size: 14px;
 		width: 120px;
 		margin-left: 15px; 
 	}
 	.btn1{
 		text-transform: uppercase;
 		font-size: 18px;
 		font-style: bold;
 		font-family: "rubik";
 		color: red;
 		padding: 5px;
 		border-radius: 20px;
 		outline: none;
 	}
 	.btn1:hover{
 		background-color: black;
 	}
 </style>