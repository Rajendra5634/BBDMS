<?php 
	if($_SESSION['id']==true)
	$id=$_SESSION['id'];
	$db = mysqli_connect("localhost","root","","bbms");
	$query2 = "SELECT a.`HID`,`HName`,`A+`,`A-`,`B+`,`B-`,`AB+`,`AB-`,`O+`,`O-` FROM blood_bank,blood_bank_manager,`horders` a,`hospital` h WHERE a.`HID`=h.`HID` AND HBBID=BBID AND BMID=MID AND MID='$id'";
	//bb.MID=m.MID and o.BBID=bb.BBID and h.HID=o.HID
	$result2 = mysqli_query($db,$query2);
	$query3 = "SELECT * FROM blood_bank,blood_bank_manager WHERE BMID='$id' and BMID=MID";
	$result3 = mysqli_query($db,$query3);
	if (mysqli_num_rows($result3)>0) {
		# code...
	
	//print_r($result2);
	//echo $result;
  if( mysqli_num_rows($result2) > 0){
              //echo "failed to get:".$mysqli->error;
           ?>
           
          <table class="t3">
          	
            <tr>
              <th>Hospital-ID</th>
              <th>Hospital Name</th>
              <th>A+</th>
              <th>A-</th>
              <th>B+</th>
              <th>B-</th>
              <th>AB+</th>
              <th>AB-</th>
              <th>O+</th>
              <th>O-</th>
            </tr>
            <?php 
                $i=0;
                while($row = mysqli_fetch_array($result2)){
                	//print_r($row);
             ?>
            <tr>
            	<td><?php echo $row["HID"]; ?></td>
            	<td><?php echo $row["HName"]; ?></td>
              <?php 
              if($row["A+"]>0)
              echo "<td>".$row["A+"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
               
               <?php 
               if($row["A-"]>0)
              echo "<td>".$row["A-"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
               <?php 
               if($row["B+"]>0)
              echo "<td>".$row["B+"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
                <?php 
               if($row["B-"]>0)
              echo "<td>".$row["B-"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
                <?php 
               if($row["AB+"]>0)
              echo "<td>".$row["AB+"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
                <?php 
               if($row["AB-"]>0)
              echo "<td>".$row["AB-"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
                <?php 
               if($row["O+"]>0)
              echo "<td>".$row["O+"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
                <?php 
               if($row["O-"]>0)
              echo "<td>".$row["O-"]."</td>";
          		else
          			echo"<td>".'0'."</td>";?>
              <?php echo "<td class='approve'><a href='manager-approve.php?approve=$row[HID]' class='ap'>Approve</td>"?>
              <?php echo "<td class='reject'><a href='manager-reject.php?reject=$row[HID]' class='re'>Reject</td>"?>
              
               
             </tr>
             <?php 
             $i++;
              }
              ?></table></form>
              <?php
              } 

              else{
                //echo "failed to get:".$mysqli->error;
                echo "<h1>"."No Orders Found"."</h1>";
              }
              }
              else {
              	echo "<h1>"."You Not Registered With Any Blood Bank"."</h1>";
              } 
              $db->close();
              ?>

              <?php 

               ?>
<style>
	 h1{
    font-size: 30px;
    font-family: arial,times new roman;
    font-style: italic;
    color: white;
    margin-left: 30px;
    width: 800px;
  }
	table.t3{
		text-transform: uppercase;
		width: 100%;
	}
	table.t3 caption{
		font-size: 20px;
		font-family: "rubik";
	}
	table.t3 th{
		width: 30px;
		background-color: black;
		height: 40px;
		color: white;
		font-family: arial,"rubik";
		font-size: 20px;
	}
	table.t3 td{
		color: black;
		height: 18px;
		font-size: 16px;
		font-family: arial,times new roman;
	
	}
	
	table.t3 tr:nth-child(odd) {background-color:white;}
	table.t3 tr:nth-child(even) {background-color: cyan;}
  td.approve,td.reject{
    width: 80px;
    background: none;
  }
  .ap,.re{
    border: 2px solid grey;
    border-radius: 20px;
    padding: 5px;
    margin: 0px;
    text-align: center;
    text-transform: uppercase;
    font-family: "rubik";
  }
  .ap{
    background-color: green;
    color: white;
  }
  .re{
    background-color: red;
    color: white;
  }
  .ap:hover{
    background-color: #80ff80;
    color: black;
  }
  .re:hover{
    background-color: #ff8080;
    color: black;
  }
</style>