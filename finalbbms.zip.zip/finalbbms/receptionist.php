<?php 
$db = mysqli_connect('localhost','root', '','bbms');

if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
 
 	$q4 = "SELECT RID,r.`Fname`,r.`Lname`,r.`Email`,r.`Rphno`,BBID FROM `receptionist` r,blood_bank,blood_bank_manager WHERE RBBID = BBID and BMID=MID and MID='$id'";
 	$result4 = mysqli_query($db,$q4);
 	//echo $result4;
 	//$num =mysqli_num_rows($result);
 	if( mysqli_num_rows($result4) > 0 ) {
 		echo "<h6>"."user already exists"."</h6>";
 		echo "<h6>"."current user details are"."</h6>";
 		while($row=mysqli_fetch_array($result4)){
 			$de = $row['RID'];
 		?>
 		<table class="t5" align="center" >
 			<tr><th class="t5">Receptionist ID :</th><td class="t5"><?php echo $row['RID']; ?></td></tr>
 			<tr><th class="t5">Name :</th><td class="t5"><?php echo $row['Fname']." ".$row['Lname']; ?></td></tr>
 			<tr><th class="t5">Email :</th><td class="tmail"><?php echo $row['Email']; ?></td></tr>
 			<tr><th class="t5">Phone no :</th><td class="t5"><?php echo $row['Rphno']; ?></td></tr>
 		</table>
 		<form method="post">
      <input type="submit" value="delete" class="btn1" name="dele"><br>
<?php 
}
	if(isset($_POST['dele'])){
	$del = "DELETE FROM receptionist WHERE RID = '$de'";
	$rdel = mysqli_query($db,$del);
	echo "<h6>Deleted successfully</h6>";
}?></form>
		
 	<?php	
 	}

 	else{
 		echo "<h6>"."No Receptionist Available"."</h6>";
 		echo"<a href='receptionist-register.php'>"."<h2>"."CLICK HERE TO ADD NEW RECEPTIONIST"."</h2>"."</a>";
 	}
  
  //else
  	//echo $db->error();
}
 ?>
 <style>
 	h2{
 		text-decoration: none;
 		font-size: 30px;
 		font-weight: 800;
 		font-family: times new roman;
 		font-style: italic;
 		color: white;
 		text-align: center;
 	}
 	h2:hover{
 		color:red;
 	}
 	table.t5{
 		line-height: 25px;
 		margin-left: 20px;
 		text-transform: uppercase;
 		font-size: 20px;
 		font-family: "rubik" arial;
 		padding-top: 10px;
 		background-color: #137523;
 		border-radius: 20px;

 	}
 	th.t5{
 		text-align: right;
 		text-transform: uppercase;
 		
 		color: black;

 	}
 	td.t5{
 		text-align: left;
 		color: #bdf0c6;
 	}
 	td.tmail{
 		text-transform: lowercase;
 		text-align: left;
 		color: #bdf0c6;
 	}
 	h6{
 		width: 300px;
 		color: pink;
 		
 		margin-top: 5px;
 		margin-bottom: 15px;
 		margin-left: 20px;
 		text-transform: capitalize;
 		text-align: center;
 		font-size: 20px;
 		font-family: times new roman;
 		font-style: italic;
 	}
 	.btn1{
 		text-transform: uppercase;
 	}
 </style>