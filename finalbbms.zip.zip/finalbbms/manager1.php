<?php  
  session_start();
  //include("manager-login.php");
  
  $db = mysqli_connect('localhost','root','','bbms');
  if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
  } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Manager control</title>
	<style>
	@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap");
* {
  margin: 0;
  padding: 0;
  list-style: none;
  box-sizing: border-box;
  font-family: "Montserrat", sans-serif;
}

body {
  background: #212131;
  font-size: 14px;
  line-height: 24px;
}

.wrapper {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: #313142;
  width: 1360px;
  height: 650px;
  display: flex;
  border-radius: 15px;
}

.wrapper .wrapper_left {
  width: 300px;
  background: #393952;
  padding: 0 25px;
  display: flex;
  align-items: center;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
  box-shadow: 10px 0px 13px 0px rgba(41, 41, 57, 0.7);
}
.wrapper .wrapper_left ul li {
  background: #313142;
  margin-bottom: 10px;
  border-radius: 3px;
  padding: 12px 25px;
  text-transform: uppercase;
  font-weight: 500;
  position: relative;
  overflow: hidden;
  width: 200px;
  letter-spacing: 2px;
  transition: all 0.4s ease;
  cursor: pointer;
}

.wrapper .wrapper_left ul li p {
  color: #abaacd;
  position: relative;
}

.wrapper .wrapper_left ul li:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background: #5437b7;
  background: linear-gradient(
    126deg,
    rgba(2, 0, 36, 1) 0%,
    rgba(123, 90, 231, 1) 0%,
    rgba(88, 54, 206, 1) 100%
  );
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transition: all 0.4s ease;
}

.wrapper .wrapper_left ul li.active {
  width: 200px;
}
.wrapper .wrapper_left ul li.active p {
  color: #fff;
}
.wrapper .wrapper_left ul li.active:before {
  width: 100%;
  transition: all 0.2s ease;
}

.wrapper .wrapper_left ul li:last-child {
  margin-bottom: 0;
}

.wrapper .wrapper_right {
  width: 1000px;
  padding: 30px 50px;
}

.wrapper .wrapper_right .title {
  font-size: 24px;
  text-align: center;
  font-weight: 700;
  color: #6b6b93;
  margin-bottom: 20px;
  text-transform: uppercase;
}

.wrapper .wrapper_right .item .item_info {
  display:inline;
  justify-content: space-around;
  align-items: left;
}
.wrapper .wrapper_right .item .item_info .img {
  width: 200px;
  height: 200px;
  background: #fff;
  border-radius: 50%;
  margin-bottom: 20px;
  position: relative;
}

.wrapper .wrapper_right .item .item_info .img:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: url("frames.png") no-repeat 0 0;
  width: 94px;
  height: 101px;
}

.wrapper .wrapper_right .item.Profile .item_info .img:before {
  background-position: 0 0;
  width: 94px;
  height: 101px;
}
.wrapper .wrapper_right .item.Blood_donors .item_info .img:before {
  background-position: 0 -110px;
  width: 89px;
  height: 101px;
}
.wrapper .wrapper_right .item.Blood_groups .item_info .img:before {
  background-position: 0 -220px;
  width: 100px;
  height: 100px;
}
.wrapper .wrapper_right .item.Add_Blood_Bank.item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.Add_receptionist  .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.Add_blood_group .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.stock_list .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.Orders .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item.logout .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}
.wrapper .wrapper_right .item .item_info p {
  background: #fff;
  width: 150px;
  padding: 10px;
  border-radius: 5px;
  color: #abaacd;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
}
.wrapper .wrapper_right .item.Profile .item_info p {
  color: #dd0330;
}
.wrapper .wrapper_right .item.Blood_donors .item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.Blood_groups .item_info p {
  color: #61dafb;
}
.wrapper .wrapper_right .item.Add_Blood_Bank .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.Add_receptionist .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.Add_blood_group .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.stock_list .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.Orders .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item.logout .item_info p {
  color: #41b783;
}
.wrapper .wrapper_right .item p {
  margin-bottom: 20px;
  color: #fff;
}
	</style>
</head>
<body>
<div class="wrapper">
  <div class="wrapper_left">
  <ul>
     <li data-li="Profile">
        <p>Profile</p>
      </li>
      <li data-li="Blood_donors">
        <p>Blood Donors</p>
      </li>
      <li data-li="Blood_groups">
        <p>Blood Groups</p>
      </li>
      <li data-li="Add_Blood_Bank">
        <p>Add Blood Bank</p>
      </li>
      <li data-li="Add_receptionist">
        <p>Add Receptionist</p>
      </li>
      <li data-li="Add_blood_group">
        <p>Add Blood Groups</p>
      </li>
      <li data-li="stock_list">
        <p>Stock List</p>
      </li>
      <li data-li="Orders">
        <p>Orders</p>
      </li>
      <li data-li="logout">
        <p>Logout</p>
      </li>
    </ul>
  </div>
  <div class="wrapper_right">
    <div class="title">
	  MANAGER
    </div>
    <div class="container">
      <div class="item Profile">
        <div class="item_info">
          <div class="img"></div>
          <p>Profile</p>
        </div>
 <?php 
            $query1= "SELECT * from donor";
            $result1 = mysqli_query($db.$query1);
           // if(mysqli_num_rows($r1) > 0){
            //  echo "failed to get:".$mysqli->error;
           ?>
           <table>
            <tr>
              <td>Donor ID</td>
              <td>Name</td>
              <td>DOB</td>
              <td>Gender</td>
              <td>Phone-No</td>
            </tr>
            <?php 
                $i=0;
                while($row = mysqli_fetch_array($result1)){
             ?>
             <tr>
               <td><?php echo $row["DID"]; ?></td>
               <td><?php echo $row["Fname"].$row["Lname"]; ?></td>
               <td><?php echo $row["DOB"]; ?></td>
               <td><?php echo $row["Gender"]; ?></td>
               <td><?php echo $row["ph_no"]; ?></td>
             </tr>
             <?php 
             $i++;
           }
              ?></table>
              <?php
              } 
              else{
                echo "failed to get:".$mysqli->error;
                echo "NO RESULTS FOUND";
              } 
              ?>
	 </div>
	 <div class="item Blood_donors" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>Blood donors</p>
        </div>
		
		
       </div>
      <div class="item Blood_groups" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>Blood groups</p>
        </div>
		
		
       </div>
	   <div class="item Add_Blood_Bank" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>Add Blood Bank</p>
        </div>
		
		
       </div>
	  <div class="item Add_receptionist" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>Add receptionist</p>
        </div>
		
		
       </div>
	   <div class="item Add_blood_group" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>Add blood groups</p>
        </div>
		
		
       </div>
	   <div class="item stock_list" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>stock list</p>
        </div>
		
		
       </div>
	   <div class="item Orders" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>Orders</p>
        </div>
		
		
       </div>
	    <div class="item logout" style="display: none;">
        <div class="item_info">
          <div class="img"></div>
          <p>logout</p>
        </div>
		
		
       </div>
  </div>
</div>
	<script>
var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "Profile") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Blood_donors") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Blood_groups") {
      document.querySelector("." + li_value).style.display = "block";
    }  else if (li_value == "Add_Blood_Bank") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Add_receptionist") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Add_blood_group") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "stock_list") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "Orders") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "logout") {
      document.querySelector("." + li_value).style.display = "block";
    } else {
      console.log("");
    }
  });
}
	</script>
</body>
</html>