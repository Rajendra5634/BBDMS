<?php 
	
if($_SESSION['hosid'] == true){
    $id= $_SESSION['hosid'];
  $_SESSION['success'] = "You are now logged in";

  $db = mysqli_connect('localhost','root','','bbms');
  $q1 = "SELECT h.`HName`,`A+`,`A-`,`B+`,`B-`,`AB+`,`AB-`,`O+`,`O-`,HBBID FROM `horders` o,`hospital` h,blood_bank where o.`HID`=h.`HID` AND HBBID=BBID AND h.`HID` ='$id'";
  $r1 = mysqli_query($db,$q1);
  if (mysqli_num_rows($r1) > 0) {
  	echo "<h3>"."Your Recent Orders are:"."</h3>";
  	?>
  	<table class="t3" align="center">
  		<tr>
  			<th>Name</th>
  			<th>A+</th>
  			<th>A-</th>
  			<th>B+</th>
  			<th>B-</th>
  			<th>AB+</th>
  			<th>AB-</th>
  			<th>O+</th>
  			<th>O-</th>
  			<th>Blood Bank ID</th>
  		</tr>
  		<?php
  		while($row = mysqli_fetch_array($r1)){

  		?>

  		<tr>
  			<td><?php echo $row['HName'];?></td>
  			<?php 
  				if($row['A+']>0) 
  					echo "<td>".$row['A+']."</td>";
  				else 
  					echo "<td>"."0"."</td>";

  				if($row['A-']>0) 
  					echo "<td>".$row['A-']."</td>";
  				else 
  					echo "<td>"."0"."</td>";
  			 
  			 	if($row['B+']>0) 
  					echo "<td>".$row['B+']."</td>";
  				else 
  					echo "<td>"."0"."</td>";
  			
  				if($row['B-']>0) 
  					echo "<td>".$row['B-']."</td>";
  				else 
  					echo "<td>"."0"."</td>";

  				if($row['AB+']>0) 
  					echo "<td>".$row['AB+']."</td>";
  				else 
  					echo "<td>"."0"."</td>";

  				if($row['AB-']>0) 
  					echo "<td>".$row['AB-']."</td>";
  				else 
  					echo "<td>"."0"."</td>";

  				if($row['O+']>0) 
  					echo "<td>".$row['O+']."</td>";
  				else 
  					echo "<td>"."0"."</td>";

  				if($row['O-']>0) 
  					echo "<td>".$row['O-']."</td>";
  				else 
  					echo "<td>"."0"."</td>";
  			?>
  			<td><?php echo $row['HBBID'];?></td>
  			
  				<?php echo "<td class='del'><a href='horders-delete.php?rn=$row[HBBID]'>delete</td>"?>
  			
  		</tr>
  	<?php
  		}
  }
  else 
  	echo "<h3>"."You not Ordered Any Blood from Blood Bank"."</h3>";
?>
</table>
  
  	
  			
  			
  			<?php //include("horders-delete.php"); ?>
  			
  <?php

  		
}
 ?>
  	
  <style>
  	table.t3{
  		width: 100%;
  		text-transform: uppercase;
  		text-align: center;
  		line-height: 30px;
  	}
  	table.t3 th{
  		font-size: 20px;
  		font-family: "rubik";
  		color:red;
  		background-color: black;
  	}
  	table.t3 td{
  		font-family: "rubik" arial;
  		font-size: 15px;
  		color: black;
  		background-color: white; 
  	}
  	table.t3. td.del{
  		background-color: blue;
  	}
  	label{
  		color: white;
  		font-size: 20px;
  		text-transform: capitalize;
  		font-family: "rubik";
  		font-style: bold;
  		font-style: italic;
  	}
  	form{

  		
  		background-color: transparent;
  	}
  	.de{
  		line-height: 10px;
  		text-transform: lowercase;
  		width: 150px;
  		border-radius: 10px;
  		padding: 5px;
  		outline: none;
  	}

  	.button{
  		text-transform: uppercase;
  		padding: 5px;
  		border-radius: 10px;
  		color: red;
  		outline: none;
  	}
  	.button:hover{
  		background-color: red;
  		color: white;
  	}
  	h3{
  		font-size: 30px;
  		color: black;
  		padding: 20px;
  	}
  </style>