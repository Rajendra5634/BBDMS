<?php 
session_start();
$db = mysqli_connect('localhost','root','','bbms');
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>user site login</title>
</head>
<?php include('header.php'); ?>
<body>
<img src="user1.jpg" align="center">

<form class="user" method="post" action="#" autocomplete="off">
	<label class="u1"> User name :</label>
	<input type="text" name="user" class="us" placeholder="user name" required>
	<input type="submit" name="bt" class="bt" value="login">
	

<?php 
	if(isset($_POST['user'])){
		$name=$_POST['user'];
		$_SESSION['user'] = $name;
		$usercheck = "SELECT * FROM user where name='$name'";
		$rcheck = mysqli_query($db,$usercheck);
		if(mysqli_num_rows($rcheck)>0)
			header('location:user.php');
		else{
		$query = "INSERT into user(`name`) values('$name')";
		$rquery = mysqli_query($db,$query);
		//echo "<script>alert('logged in successfully')</script>";
		header('location:user.php');
	}
	}

 ?>


</form>
<p class="glow"><b>* Note: User Don't Need TO Register Just Enter Name</b></p>
<?php include('footer.php'); ?>
</body>

</html>
<style>
	*{
		margin: 0px;
	}
	body{
		color: black;
		align-items: center;
		background-repeat:no-repeat;
		position: relative;
		margin-bottom: 0px;
	}
	img{
		align-content: center;
		margin-left: 45%;
		margin-top: 10%;

	}
	.user{
		margin-left: 40%;
		margin-top: 10px;
		margin-bottom: 23px;
		width: 35%;
		padding: 10px;

	}
	.u1{
		text-transform: uppercase;
		display: inline-block;
		text-align: right;
		font-family: "rubik";
		font-size: 18px;
		font-weight: bold;
		padding: 10px;
	}
	.us{
		text-align: center;
		font-size: 18px;
		font-family: "rubik";
		width: 150px;
		outline: none;
		border:none;
		border-bottom: 2px solid red;
		text-transform: capitalize;
		padding-bottom: 5px;
	}
	::placeholder{
		font-size: 20px;
		font-family: "rubik";
		text-transform: capitalize;
	}
	.bt{
		outline: none;
		border:none;
		background-color: red;
		color: black;
		font-size: 20px;
		font-family: "rubik";
		text-transform: capitalize;
		border-radius: 10px;
		padding: 5px;
	}
	.bt:hover{
		background-color: green;
		color: white;
	}
	.glow{
		margin-top: 30px;
		font-size: 18px;
		font-style: italic;
		font-family: "rubik";
		color: red;

	
	 
        
        text-align: center;
        -webkit-animation: glow 1s ease-in-out infinite alternate;
        -moz-animation: glow 1s ease-in-out infinite alternate;
        animation: glow 1s ease-in-out infinite alternate;
      }
      @-webkit-keyframes glow {
        from {
          text-shadow: 0 0 10px #eeeeee, 0 0 20px #000000, 0 0 30px #000000, 0 0 40px #000000, 
                       0 0 50px #9554b3, 0 0 60px #9554b3, 0 0 70px #9554b3;
        }
        to {
          text-shadow: 0 0 20px #eeeeee, 0 0 30px #ff4da6, 0 0 40px #ff4da6, 0 0 50px #ff4da6,
                       0 0 60px #ff4da6, 0 0 70px #ff4da6, 0 0 80px #ff4da6;
        }
      }
</style>
<?php  ?>