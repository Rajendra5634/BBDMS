<?php 
          $db = mysqli_connect("localhost","root","","bbms");
            $query1= "SELECT * from donor";
            $result1 = $db->query($query1);
            if(mysqli_num_rows($result1) > 0){
              //echo "failed to get:".$mysqli->error;
           ?>
           <table class="t1">
            <tr>
              <th>Donor ID</th>
              <th>Name</th>
              <th>DOB</th>
              <th>Gender</th>
              <th>Phone-No</th>
            </tr>
            <?php 
                $i=0;
                while($row = mysqli_fetch_array($result1)){
             ?>
             <tr>
               <td><?php echo $row["DID"]; ?></td>
               <td><?php echo $row["Fname"]."\t".$row["Lname"]; ?></td>
               <td><?php echo $row["DOB"]; ?></td>
               <td><?php echo $row["Gender"]; ?></td>
               <td><?php echo $row["ph_no"]; ?></td>
             </tr>
             <?php 
             $i++;
              }
              ?></table>
              <?php
              } 
              else{
                echo "failed to get:".$mysqli->error;
                echo "NO RESULTS FOUND";
              } 
              $db->close();
              ?>