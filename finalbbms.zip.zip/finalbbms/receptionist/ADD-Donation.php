<?php 
include "connection.php";
//session_start();
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


 // $db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  ?>
  <form class="f1" action="#" method="post" align="center"  autocomplete="off">
    <label class="lab">Donor ID :</label>
  	<input type="text" name="did" class="did" placeholder="Donor-ID" required><br>
    <label class="lab">Code :</label>
    <input type="text"  name="code" class="code" placeholder="Blood code" required><br>
    <label class="lab">Amount :</label>
    <input type="number"  name="amount" class="amount" placeholder="blood Amount"><br> 
	<label class="lab">Select Blood Group :</label>
	<select name="choose" class="choose" required>
	<option value="choose">choose blood group</option>
	<option value="A+">A+</option>
	<option value="A-">A-</option>
	<option value="B+">B+</option>
	<option value="B-">B-</option>
	<option value="AB+">AB+</option>
	<option value="AB-">AB-</option>
	<option value="O+">O+</option>
	<option value="O-">O-</option>
	</select><br>
     <input type="submit" name="add" class="btn2" value="ADD"></b><br>
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
      
      
    

  <?php
      if(isset($_POST['add']))
	  {
	$did = $_POST['did'];
	$code = $_POST['code'];
	$amount = $_POST['amount'];
	$choose = $_POST['choose'];
	//echo $choose;
  $bcheck ="SELECT blood_type from blood where EXISTS(select DID from donor where DID=B_DID and DID='$did')limit 1";
  $rbcheck = mysqli_query($db,$bcheck);
  $get = "SELECT RBBID FROM receptionist WHERE RID='$id'";
  $set = "SELECT DID from donor Where DID='$did'";
  $g1 = "SELECT * FROM blood where code='$code'";
  $rg1 = mysqli_query($db,$g1);
  if($choose != 'choose'){
   //   $rbcheck = mysqli_query($db,$bcheck);
    //if(mysqli_num_rows($rbcheck)==0){
      
    if(mysqli_num_rows($rg1)==0){
      $rset = mysqli_query($db,$set);
  if(mysqli_num_rows($rset)>0){
      $rget = mysqli_query($db,$get);
  if(mysqli_num_rows($rget)>0){
    while($row=mysqli_fetch_array($rget))
      $bbid = $row['RBBID'];
    $add = "INSERT into blood(`code`,`B_DID`,`Amount`,`blood_type`,`BBID`) VALUES('$code','$did','$amount','$choose','$bbid')";
    $radd = mysqli_query($db,$add);
    

    $check1 = "SELECT BBID,`$choose` FROM blood_stock WHERE BBID='$bbid'";
    $rcheck1 = mysqli_query($db,$check1);
    if(mysqli_num_rows($rcheck1)>0){
      $rcheck11 = mysqli_query($db,$check1);
      if(mysqli_num_rows($rcheck11)>0){
        while($row=mysqli_fetch_array($rcheck11))
          $group = $row[$choose];
      
        
    $adb = "UPDATE blood_stock SET `$choose`= '$group'+1 WHERE BBID='$bbid'";
    $rabd = mysqli_query($db,$adb);
    if($rabd)
      echo"<script type='text/javascript'> alert('Added successfully')</script>";
    else
      echo"<script type='text/javascript'> alert('error : try again')</script>";
  }
  else{
     $rcheck11 = mysqli_query($db,$check1);
      if(mysqli_num_rows($rcheck11)>0){
        while($row=mysqli_fetch_array($rcheck11))
          $group = $row[$choose];
      
    $abd1 = "INSERT INTO blood_stock VALUES('$bbid',0,0,0,0,0,0,0,0)";
    $rabd1 = mysqli_query($db,$abd1);
    $abd2 = "UPDATE blood_stock SET `$choose`= '$group'+1 WHERE BBID='$bbid'";
    $rabd2 = mysqli_query($db,$abd2);
    if($rabd2 && $rabd1)
      echo"<script type='text/javascript'> alert('Added successfully')</script>";
    else
      echo"<script type='text/javascript'> alert('error cant insert')</script>";
  }
}

  }
}
  else
    echo"<script type='text/javascript'> alert('not registerd with any blood bank')</script>";

}
else
  echo"<script type='text/javascript'> alert('Donor not exists')</script>";
}


else
  echo "<script>alert('Record Already Present check once again')</script>";
//}
}
//else{
 // while($b = mysqli_fetch_array($rbcheck))
 //       $type = $b['blood_type'];
 //     if($choose != $type)
  //      echo"<script>alert('select correct blood group')</script>";
    //}
  
else 
  echo"<script>alert('Choose blood group')</script>";
}
}



	?>
     
</form>
         <style>
           h6{
            text-transform: capitalize;
            font-size: 20px;
            font-family: "rubik";
            color: pink;
            font-style: italic;
          }
          .f1{
            width: 300px;
            margin-left:30px;
            padding:10px;
			   font-weight:bold;
			   text-align:left;
          border: 1px solid black;
          border-radius: 20px;
          background-color: white;
          }
	 .l1{
			  margin-left:5px;
			
		  }
      .lab{
        width: 150px;
        display: inline-block;
        text-transform: capitalize;
        text-align: right;
      }
		 
         .did,.code,.amount,.choose{
          display: inline-block;
          width: 100px;
			     margin-left:0px;
            
            padding: 10px; 
            margin-bottom: 10px;
            border: 1px solid blue;
            outline: none;
           border-radius: 20px;
            font-size: 12px;
            text-align:center;
			     color:black;
          }
         ::placeholder{
            opacity: 1;
            color: black;
            font-size: 14px;
          }
         .btn2{
            border:2px solid black;
            background-color: black;
            color: white;
            border-radius: 30px ;
            padding: 10px;
            margin-left: 100px;
            outline: none;
          } 
          .btn2:hover{
            background-color: white;
            color: black;

          }
         </style>           
