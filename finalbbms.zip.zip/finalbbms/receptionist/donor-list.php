<?php
include "connection.php";
?>
<style> 
.D4{
	border-collapse:collapse;
	margin:25px 0;
	font-size:0.9em;
	width:100%;
	margin-left:20px;
	font-weight:bold;
	background:white;
	text-transform: capitalize;
}
.D4 th{
	background-color:black;
	color:#fff;
	text-align:center;
	font-weight:bold;	
}
.D4 td{
	text-align:center;
	padding:12px 15px;
	color:black;
	font-weight:bold;
}
</style>
<table class="D4">

<?php
$qr="select DID,Fname,Lname,DOB,Gender,ph_no from donor";
$result=$conn->query($qr);
if ($result->num_rows>0) 
{

echo"<tr>";
echo"<th>DID</th>";
echo"<th>Fname</th>";
echo"<th>Lname</th>";
echo"<th>DOB</th>";
echo"<th>Gender</th>";
echo"<th>ph_no</th>";
echo"</tr>";

    // output data of each row
    while($row=$result->fetch_assoc()) 

	{

        echo "<tr><td>".$row["DID"]."</td><td>".$row["Fname"]."</td><td>".$row["Lname"]."</td><td>".$row["DOB"]."</td><td>".$row["Gender"]."</td><td>".$row["ph_no"]."</td></tr>";
    }
    echo"</table>";
?>
<?php
}
else
{
    echo "<h1>0 results</h1>";
}
$conn->close();
?>