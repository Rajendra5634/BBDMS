<?php 
include "connection.php";
//session_start();
if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


//$db = mysqli_connect('localhost','Amith','Amith#06','bbms');

 ?>
 <form class="pass" action="#" method="post" autocomplete="off" align="center">
 	<label class="change">Enter old Password / phone-no</label><br>
 	<input type="password" name="old" class="pwd" placeholder="old password / ph-no" required><br>
 	<label class="change">enter new password</label><br>
 	<input type="password" name="p1" class="pwd" placeholder="new password" required><br>
 	<label class="change">re-enter new password</label><br>
 	<input type="password" name="p2" class="pwd" placeholder="re-enter password" required><br>
 	<?php 

 if(isset($_POST['old'])){
 		$old = $_POST['old'];
 		$p1 = $_POST['p1'];
 		$p2 = $_POST['p2'];

 	$change = "SELECT * FROM receptionist WHERE `password` = '$old' OR Rphno = '$old' AND RID = '$id'";
 	$rchange = mysqli_query($db,$change);
 	$ic = "UPDATE receptionist SET password = '$p1' WHERE RID = '$id'";
 	if($p1==$p2){
 		if(mysqli_num_rows($rchange) > 0){
 			$ric = mysqli_query($db,$ic);
 			echo "<h2><script type='text/javascript'> alert('Password changed successfully')</script></h2>";

 		}else
 		echo "<h2><script type='text/javascript'> alert('Invalid password/phone number')</script></h2>";
 	}
 	else
 		echo "<h2><script type='text/javascript'> alert('Wrong Password Combination')</script></h2>";
 }
}
  ?>
 	<input type="submit" name="btn" value="change password" class="button">
 </form>

 

 <style>
 	h2{
 		text-transform: capitalize;
 		font-size: 22px;
 		color: pink;
 		margin-bottom: 0px;
 	}
 	.pass{
 		
 		margin-left:30px;
 		display: block;
 		width: 340px;
 		padding: 20px;
 		box-sizing: border-box;
 		border:2px solid green;
 		border-radius: 40px;
 		background-color: #606157;
 		
 	}
 	.pwd{
 			width: 180px;
			padding: 2px 2px 2px 2px;
			margin: 0px;
			margin-bottom: 15px;
			background: transparent;
			border: 1px solid black;
			border-radius: 20px;
			outline: none;
			color: black;
			background-color: white;
			vertical-align: middle;
			font-size: 24px;
			text-align: center;
 	}
 	.change{
 		width: 300px;
 		text-align: center;
 		text-transform: capitalize;
 		font-family: "rubik";
 		font-size: 18px;
 		color: white;
 	}
 	.pwd::placeholder{
 		text-transform: capitalize;
 		font-size: 13px;
 		text-align: center;
 		color: black;
 	}
 	.button{
 		margin: 0px;
 		text-align: center;
 		text-transform: capitalize;
 		background-color: green;
 		color: white;
 		outline: none;
 		border:2px solid green;
 		border-radius: 20px;
 		padding: 10px;
 		font-size: 16px;
 		font-family: "rubik";
 	}
 	.button:hover{
 		background-color: black;
 		color: pink;
 	}

 </style>