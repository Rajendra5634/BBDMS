<?php 
	include "connection.php";
	?>
	<style>
	 .D1 {
	border-collapse:collapse;
	margin-top:10px;
	font-size:16px;
	min-width:400px;
	margin-left:260px;
	font-weight:bold;
     
	 color:white;
	 background-color: black;
	 border-radius: 20px;
}
.D1 .tr0 .td0{
color:white;
	text-align:right;
	font-weight:bold;	
	border-bottom:2px;
	padding-right: 20px;
}
.D1 .tr0 .td01{
color:white;
	text-align:left;
	font-weight:bold;	
	padding:12px 15px;
	border-bottom:2px;
	padding-left: 20px;
	text-transform: capitalize;
}
.D1 .tr1 .td1{
color:white;
	text-align:right;
	font-weight:bold;	
	border-bottom:2px;
	padding-right: 20px;
}
.D1 .tr1 .td2{
color:white;
	text-align:left;
	font-weight:bold;	
	padding:12px 15px;
	border-bottom:2px;
	padding-left: 20px;
	text-transform: capitalize;
}
.D1 .tr2 .td3{
color:white;
	text-align:right;
	font-weight:bold;	
	border-bottom:2px;
	padding-right: 20px;
}
.D1 .tr2 .td4{
color:white;
	text-align:left;
	font-weight:bold;	
	padding:12px 15px;
	border-bottom:2px;
	padding-left: 20px;
	text-transform: capitalize;
}
.D1 .tr3 .td5{
color:white;
	text-align:right;
	font-weight:bold;	
	border-bottom:2px;
	padding-right: 20px;
}
.D1 .tr3 .td6{
color:white;
	text-align:left;
	font-weight:bold;	
	padding:12px 15px;
	border-bottom:2px;
	padding-left: 20px;
	text-transform: capitalize;
}
.D1 .tr5 .td9{
color:white;
	text-align:right;
	font-weight:bold;	
	border-bottom:2px;
	padding-right: 20px;
}
.D1 .tr5 .td10{
color:white;
	text-align:left;
	font-weight:bold;	
	padding:12px 15px;
	border-bottom:2px;
	padding-left: 20px;
	text-transform: capitalize;
}
img.im{
	width:200px;
	height:200px;
	border-radius: 50%;
	margin-bottom: 0px;
	margin-left: 350px;
}
	</style>
	<?php
	if($_SESSION['id'] == true){
   $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";
  
 				$qr="select RID,Fname,Lname,Email,Rphno from receptionist where RID='$id'";

			$result=$conn->query($qr)or die(mysqli_error());
			if ($result->num_rows>0)
			{				
 			while($row=$result->fetch_assoc())
			{
 				//echo "<div style='text-align: center'>
 				//	<img class='img-circle profile-img' height=110 width=120 src='C:\Users\130cs\Pictures\Saved Pictures\hostel.jpg'".$_SESSION['pic']."'>
 				//</div>";
	 				// echo $_SESSION['id'];
					?>
					<img class="im" src="Rprofile.png" align="center">
 				<table class="D1">
				<tr class="tr0">
	 					<td class="td0">
	 		<b> Receptionist-ID</td><td>:</td><td class="td01"><?php echo $row['RID'];?></td>
	 				</tr>
	 				<tr class="tr1">
	 					<td class="td1">
	 		<b> First Name</td><td>:</td><td class="td2"><?php echo $row['Fname'];?></td>
	 				</tr>
					<tr class="tr2">
	 					<td class="td3">
	 					<b> Last Name  </td><td>:</td><td class="td4"> <?php echo $row['Lname'];?>
	 				</td>
					</tr>
					<tr class ="tr3">
					<td class="td5"><b>Email</td><td>:</td>
	 					<td class="td6"><?php 	echo $row['Email'];?>
	 					</td>
						</tr>
						
						<tr class="tr5">
						<td class="td9">
						<b> phone Number</td><td> :</td>
						<td class="td10"><?php echo $row['Rphno'];?>
	 					</td>
						</tr>
				</table>
 				</b>
				<?php
			}
			}
	}
			?>