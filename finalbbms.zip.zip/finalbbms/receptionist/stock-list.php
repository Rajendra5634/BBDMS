<?php 
include "connection.php";
	if($_SESSION['id']==true)
	$id=$_SESSION['id'];
	//$db = mysqli_connect("localhost","Amith","Amith#06","bbms");
	$query2 = "SELECT `A+`,`A-`,`B+`,`B-`,`AB+`,`AB-`,`O+`,`O-` FROM `blood_bank` bb,receptionist,`blood_stock` b WHERE b.`BBID`=bb.`BBID` AND b.`BBID`=RBBID AND RID='$id'";
	//bb.MID=m.MID and o.BBID=bb.BBID and h.HID=o.HID
	$result2 = mysqli_query($conn,$query2)or die(mysqli_error());
	$query3 = "SELECT * FROM blood_bank,receptionist WHERE RID='$id' and BBID=RBBID";
	$result3 = mysqli_query($conn,$query3)or die(mysqli_error());
	if (mysqli_num_rows($result3)>0) {
		# code...
	
	//print_r($result2);
	//echo $result;
  if( mysqli_num_rows($result2)>0)
  {
              //echo "failed to get:".$mysqli->error;
           ?>
          <table class="t4" align="center">
          	
          <tr>
            <th class="thead2">Stock Name</th>
            <th class="thead1">Availability</th>
          </tr>
          
            <?php 
                $i=0;
                while($row = mysqli_fetch_array($result2)){
                	//print_r($row);
             ?>

              <tr>
              <?php 
              if($row["A+"]>0)
              echo "<th class='thead'>".'A+ :'."</th>"."<td>".$row["A+"]."</td>"."<br>";
          		?>  
              </tr>
               <tr>
               <?php 
               if($row["A-"]>0)
              echo "<th class='thead'>".'A- :'."</th>"."<td>".$row["A-"]."</td>";
          		?>  
              </tr>
              <tr>
               <?php 
               if($row["B+"]>0)
              echo "<th class='thead'>".'B+ :'."</th>"."<td>".$row["B+"]."</td>";
          		?>
                </tr>
              <tr>
                <?php 
               if($row["B-"]>0)
              echo "<th class='thead'>".'B- :'."</th>"."<td>".$row["B-"]."</td>";
          		?></tr>
              <tr>
                <?php 
               if($row["AB+"]>0)
              echo "<th class='thead'>".'AB+ :'."</th>"."<td>".$row["AB+"]."</td>";
          		?></tr>
              <tr>
                <?php 
               if($row["AB-"]>0)
              echo " <th class='thead'>".'AB- :'."</th>"."<td>".$row["AB-"]."</td>";
          		?></tr>
              <tr>
                <?php 
               if($row["O+"]>0)
              echo "<th class='thead'>".'O+ :'."</th>"."<td>".$row["O+"]."</td>";
          		?></tr>
              <tr>
                <?php 
               if($row["O-"]>0)
              echo "<th class='thead'>".'O- :'."</th>"."<td>".$row["O-"]."</td>";
          		?>
            </tr>
               
             
             <?php 
             $i++;
              }
              ?></table>
              <?php
              } 
              else{
                echo "failed to get:".$mysqli->error;
                echo "<h1>"."<script type='text/javascript'> alert('STOCK IS EMPTY')</script>"."</h1>";
              }
              }
              else {
              	echo "<h1>"."<script type='text/javascript'> alert('YOU NOT REGISTERED WITH ANY BLOOD BANK')</script>"."</h1>";
              } 
              $conn->close();
              ?>
<style>
  .wrapper .wrapper_right .item h1{
	  margin-top:250px;
    text-align: center;
    font-size: 30px;
    font-family: arial,times new roman;
    font-style: italic;
  }
	.wrapper .wrapper_right .item table.t4{
		margin-top:160px;
    width: 30%;
    margin-left: auto;
    margin-right: auto;
    border-collapse: collapse;
	padding:5px;
	color: black;
	background-color:transparent;
    
  }
 .wrapper .wrapper_right .item table.t4 th.thead{
    width: 12%;
    text-align: right;
    color: black;
    background-color:transparent;
    padding: 8px;
    margin: 0px;
    border-bottom: 2px solid transparent;

  }
  .wrapper .wrapper_right .item table.t4 th.thead2{
    width:12%;
    text-align: right;
    color: black;
    background-color:transparent;
    padding: 8px;
  }
 .wrapper .wrapper_right .item table.t4 th.thead1{
    width:12%;
    text-align: left;
    color: black;
    background-color: transparent;
    padding: 8px;
  }
 .wrapper .wrapper_right .item table.t4 td{
    width: 12%;
    text-align: left;
    background-color: transparent;
   color: black;
    padding: 8px;
    
  }
</style>