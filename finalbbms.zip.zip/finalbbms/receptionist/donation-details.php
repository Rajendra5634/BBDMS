<?php 
//session_start();
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";

	$db = mysqli_connect('localhost','root','','bbms');

 ?>
 <table class="det1">
 	<?php
       $get = "SELECT DID,code,blood_type,Amount,D_date FROM donor,receptionist,`blood` b,`blood_bank` a WHERE DID=B_DID AND RBBID=a.`BBID` AND a.`BBID`=b.`BBID` AND RID='$id'";
       $rget = mysqli_query($db,$get);
       if(mysqli_num_rows($rget)>0){
?>
		<tr class="head">
 			<th>Donor ID</th><th>Code</th><th>Blood Type</th><th>Amount</th><th>Donation Date</th>
 		</tr>
<?php
       	while($row = mysqli_fetch_array($rget)){
       		$did1 = $row['DID'];
       		$code = $row['code'];
       		$type = $row['blood_type'];
       		$amount = $row['Amount'];
       		$date = $row['D_date'];
       		?>
		<tr class="data">
 			<td><?php echo $did1; ?></td><td><?php echo $code; ?></td><td><?php echo $type; ?></td><td><?php echo $amount; ?></td><td><?php echo $date; ?></td>
 		</tr>
       		<?php
       	}

       }
       else
       	echo "<h8><b>No Donation Received</b></h8>";
 	 ?>
 		
 	
 	
 		
 	
 </table>
 <?php 
 }
  ?>
  <style>
  	.det1{
  		width: 90%;
  		margin-top: 5%;
  		margin-left: 5%;
  		padding: 5px;
  		text-transform: capitalize;
  		outline: none;
  		border-collapse: collapse;
  	}
  	.head{
  		background-color: black;
  		color: white;
  		padding: 5px;
  		font-family: "rubik";
  		font-size: 18px;
  	}
  	.data{
  		text-align: center;
  		font-size: 16px;
  		font-family: "rubik";
  		padding: 10px;
  		background-color: grey;
  		color: cyan;
  	}
  	h8{
  		font-family: "rubik";
  		font-size: 26px;
  		color: black;
  		margin-left: 5%;
  		margin-top: 5%;
  		background-color: green;
  		padding: 10px;
  		border-radius: 10px 2px 5px 0px;
  	}

  </style>