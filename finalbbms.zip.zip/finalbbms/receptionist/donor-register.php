<?php
include "connection.php";
session_start();
if($_SESSION['id'] == true){
    $id= $_SESSION['id'];
  $_SESSION['success'] = "<script type='text/javascript'> alert('logged in successfully')</script>";
 // $db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>signup Donor</title>

<link href="http://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
<style type="text/css">
	*{
margin: 0;
padding: 0;
box-sizing: border-box;
text-decoration: none;
}
body{
font-family: 'Raleway', sans-serif;
background: url(rep3.jpg);
background-repeat: no-repeat;
background-size: cover;
}
.background{
background-image: url(rep3.jpg); 
margin: 0px;
padding-bottom: 110px;
background-size: cover;

width: 100%;
display: flex;
}
.text, .box{
margin-top: 45vh;
}
.text{
margin-top: 20%;
margin-left: 0%;
max-height: 300px;
width: 200px;
}
.box{
margin-top: 2%;
padding-left: 30%;
flex: 1;
}
.text h1{

font-size: 70px;
color: black;
font-weight: 500;

}
.text p{
font-size: 20px;
color: black;
font-weight: 300;
}
.text p a{
color: #fff;
font-weight: 700;
}
.text p a:hover{
	color: red;
}
.form{
background: white;
opacity: 0.9;
color: black;
font-size: 18px;
font-family: times new roman;
box-sizing: border-box;
display: flex;
flex-direction: column;
width: 450px;
border-color: black;
border-radius: 25px;
padding: 20px;
}
img{
	border-image: white;
	margin: 0px;
	width: 70px;
	height: 60px;
	align-items: center;
}
label{
	margin:10px 5px;
	padding: 0px;
	float: right;
	font-size: 20px;
	font-family: times new roman;
	font-style: bold italic;
	flex-direction: absolute;
	color: black;
}

input{
margin: 10px 0;
padding: 10px;
background: transparent;
border: 1px solid black;
border-radius: 20px;
outline: none;
color: black;
background-color: white;
font-family: 'Raleway', sans-serif;
}
.did, .rdid, .username, .dob, .gender, .phoneno, .address{
border: 2px solid black;
border-radius: 20px;

}
.radio{
	text-align: center;
	display: inline;
}

::placeholder{
	color: black;
	opacity: 1;
}
.button{
background: black;
border: 2px solid yellow;
border-radius: 20px;
color: #fff;
font-size: 19px;
width: 150px;
}
.button:hover{
background: yellow;
color: black;
}
</style>
</head>
<body>
<main>
<div class="background">
<div class="text">
<h1>ADD New Donor</h1>
<p><a href="receptionist.php">Go Back To Home</a></p>
</div>
<div class="box">
<form class="form" action="#" method="post" autocomplete="off">
	<img src="user-logo.png" align="center">
	
<label>Donor-ID:<br><input type="text" name="did" class="did" placeholder="Donor-ID"required></label>
<label>UserName:<br><input type="text" name="fname" class="username" placeholder="first name"required>
				<input type="text" name="lname" class="username" placeholder="last name"></label>
<label>Date-of-Birth:<br><input type="date" name="dob" class="dob" placeholder="eg:dd/mm/yyyy"required></label>
<label>Gender:<label><input type="radio" id="other" class="radio" name="gender" value="other" required>Others</label>
 	<label><input type="radio" id="female" class="radio" name="gender" value="female" required>Female</label>
 	<label><input type="radio" id="male" class="radio" name="gender" value="male" required>Male</label></label>
<label>Phone-no:<br><input type="number" name="phno" class="phoneno" placeholder="eg:1234567890"required></label>
<label>Address:<br><input type="text" name="house_no" class="address" placeholder="House no"required>
					<input type="text" name="street" class="address" placeholder="Street"required>
					<input type="text" name="area" class="address" placeholder="Area"required>
					<input type="text" name="city" class="address" placeholder="City"required>
					<input type="text" name="state" class="address" placeholder="State"required>
					<input type="number" name="pincode" class="address" placeholder="pincode"required></label>
<?php 
if(isset($_POST['did'])){
	$DID = $_POST['did'];
	//$R_DID = $_POST['rdid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$dob = $_POST['dob'];
	$gender = $_POST['gender'];
	$phno = $_POST['phno'];
	$house_no = $_POST['house_no'];
	$street = $_POST['street'];
	$area = $_POST['area'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$pincode = $_POST['pincode'];

	//inserting the entered values to database
  	$query = "INSERT INTO donor VALUES('$DID','$fname','$lname','$dob', '$gender', '$phno', '$id')";
  	$query1 = "INSERT INTO daddress2 (pincode, city, state) 
  			   SELECT '$pincode','$city','$state' from daddress2 WHERE NOT EXISTS(SELECT 'pincode' from daddress2 where pincode='$pincode') limit 1";

  	$query2 = "INSERT INTO address VALUES('$DID', '$house_no', '$street', '$area', '$pincode')";
  	//mysqli_query($db,$query);
  	//mysqli_execute($db,$query);
  	//$rquery = mysqli_query($db,$query1);
	if(($db->query($query1)==true)){
  	if(($db->query($query)==true)&&($db->query($query2)==true)){
  		
  	echo"<script type='text/javascript'> alert('Donor Added successfully')</script>";}
   else
   	echo"<script type='text/javascript'> alert('Check Donor ID correctly')</script>";
  	
  	
}
  	else
  	echo'error:'.$query.'<br>'.$db->error;
}



 $db->close();
}
 ?>
<input type="submit" name="submit" class="button" value="Signup">
</form>
</div>
</div>
</main>
</body>
</html>