<?php 
include "connection.php";
//session_start();
if($_SESSION['id'] == true)
{
    $id= $_SESSION['id'];
  $_SESSION['success'] = "You are now logged in";


  //$db = mysqli_connect('localhost','Amith','Amith#06','bbms');
  ?>
  <form class="pass1" action="#" method="post" align="center"  autocomplete="off">
    <input type="text"  name="Fname" class="fname" placeholder="First name" required><br>
    <input type="text"  name="Lname" class="lname" placeholder="Last name" required><br>
   <input type="text" name="Email" class="email" placeholder="Email" required><br>  
  <input type="number"  name="Rphno" class="rphno" placeholder="Phone no" required><br>
    <input type="submit" name="update" class="btn" value="UPDATE"><br>
    
          
   
      <!--<h6>*Note: Enter data which feild you want to update</h6>-->
  <?php
      if(isset($_POST['update']))
	  {
		
       $qr= "UPDATE receptionist SET Fname ='$_POST[Fname]',Lname='$_POST[Lname]',Email='$_POST[Email]',Rphno='$_POST[Rphno]' WHERE RID='$id'";
      $rup=mysqli_query($conn,$qr)or die(mysqli_error());
	  if($rup)
	  {
		echo '<script type="text/javascript"> alert("Updated successfully")</script>';
      }
	  else
       echo '<script type="text/javascript"> alert("Not Updated Check Once Again")</script>';
	  }	
	  }
else		
 echo $conn->error();
  ?>
</form>
         <style>
       
          .pass1{
           margin-top:40px;
 		margin-left:30px;
 		display: block;
 		width: 340px;
 		padding: 20px;
 		box-sizing: border-box;
 		border:2px;
 		border-radius: 40px;
 		background:white;

          }
			.fname, .lname, .email, .password, .rphno{
             width: 180px;
			padding: 10px;
			margin: 0px;
			margin-bottom: 15px;
			background: transparent;
			border: 1px solid black;
			border-radius: 20px;
			outline: none;
			color: white;
			background-color: black;
			vertical-align: middle;
			font-size: 15px;
			text-align: center;
          }
         ::placeholder{
            text-transform: capitalize;
 		font-size: 13px;
 		text-align: center;
 		color: white;
          }
          .btn{
           margin: 0px;
 		text-align: center;
 		text-transform: capitalize;
 		background-color: green;
 		color: white;
 		outline: none;
 		border:2px solid green;
 		border-radius: 20px;
 		padding: 10px;
 		font-size: 16px;
 		font-family: "rubik";
          } 
        .btn:hover{
           background-color: black;
 		color: pink;
          }
         </style>          
          
