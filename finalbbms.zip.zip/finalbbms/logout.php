<?php
unset($_SESSION["id"]);
header("Location:manager-login.php");
?>