<?php 
session_start();
$db = mysqli_connect('localhost','root','','bbms');
if($_SESSION['user'] == true)
{
    $id= $_SESSION['user'];
  $_SESSION['success'] = "You are now logged in";
  //echo"<script>alert('you are logged in')</script>";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<?php include('header.php'); ?>
<body>
<h1 class="h1">Hi <?php echo"$id";?>,</h1><br>
<div class="full">
	<div class="left">
		<ul><li data-li="search">
        <p>Search Blood</p>
      </li>
      <li data-li="donor">
        <p>Find Donor</p>
      </li>
       <li data-li="log">
        <p><a href="user-login.php">Logout</a></p>
      </li>
  </ul>
		
	</div>
	<div class="right">
    <div class="container">
      <div class="item search" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Search Blood</p>
          	<?php include('search-blood.php'); ?>
        </div>

	</div>
   <div class="item donor" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Find Donor </p>
          	<?php include('find-donor.php'); ?>
        </div>
   </div>

	</div>
</div>
</div>
<?php  ?>

<?php include('footer.php'); ?>
</body>

</html>


<?php
}
else
echo "error".$id;
 ?>
 <style>
 	body{
 		background:url(user2.jpg);
 		color: white;

 	}
 	a{
 		text-decoration: none;
 		color: red;
 	}
 	.h1{
 		text-align: left;

 		text-decoration:underline;
 		text-decoration-color: red;
 		margin-left: 20px;
 		font-family: "rubik";
 		font-size: 28px;
 	}
 	.full{
 		width: 100%;
 		position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: transparent;
  height: 500px;
  display: flex;
  border-radius: 15px;
 	}

 	.full .left {
  width: 20%;
  background: transparent;
  padding: 10px;
  display: flex;
  align-items: center;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
  

}
.full .left ul li {
  background: white;
  margin-bottom: 25px;
  border-radius: 3px;
  padding: 5px;
  text-transform: uppercase;
  font-weight: 500;
  position: relative;
  overflow: hidden;
  width: 100%;
  letter-spacing: 2px;
  transition: all 0.4s ease;
  cursor: pointer;
}

.full .left ul li p {
  color: red;
  position: relative;
}

.full .left ul li:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background: black;
  background: linear-gradient(
    126deg,
    yellow 2%,
    yellow 2%,
    black 100%
  );
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transition: all 0.4s ease;
}

 	.full .left ul li.active {
  width: 100%;
}
.full .left ul li.active p {
  color: #fff;
}
.full .left ul li.active:before {
  width: 100%;
  transition: all 0.2s ease;
}

.full .left ul li:last-child {
  margin-bottom: 0;
}
.left{
 	min-height: 350px;
 }
 .right{
 	width: 80%;
 	margin-top: 20px;
 		
 }
 .full .right .item .item_info {
  display:inline;
  justify-content: space-around;
  align-items: left;
}

.full .right .item .item_info p {
  background-color: black;
  width: 200px;
  color: red;
  padding: 10px;
  border-radius: 5px;
  
  font-weight: 700;
  font-size: 20px;
  text-transform: uppercase;
  text-align: center;
}
.full .right .item.angular .item_info p {
  color: #dd0330;
}
.full .right .item.nodejs .item_info p {
  color: #8bc500;
}
.full .right .item.reactjs .item_info p {
  color: #61dafb;
}
.full .right .item.vuejs .item_info p {
  color: #41b783;
}

.full .right .item p {
  margin-bottom: 20px;
  color: white;
}
 	.left ul li{
 		 
 		padding: 10px;

 		padding: 5px;
 		color:red;
 		width:150px;
 		margin-bottom: 10px;
 		text-transform: capitalize;
 		text-align: center;
 	}
 	
 </style>
 <script>
var li_elements = document.querySelectorAll(".left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "search") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "donor") {
      document.querySelector("." + li_value).style.display = "block";
    } 
      console.log("");
    });
  }

	</script>