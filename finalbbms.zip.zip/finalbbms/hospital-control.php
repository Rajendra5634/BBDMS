<?php 
session_start();
$db=mysqli_connect('localhost','root','','bbms');
if($_SESSION['hosid'] == true){
    $id= $_SESSION['hosid'];
  $_SESSION['success'] = "You are now logged in";
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hospital Control</title>
	<style>
	@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap");
* {
  margin: 0;
  padding: 0;
  list-style: none;
  box-sizing: border-box;
  font-family: "Montserrat", sans-serif;
}

body {
  
  font-size: 14px;
  line-height: 24px;
  background: url(hos1.jpg);
  background-repeat: no-repeat;


  
}

.wrapper {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: transparent;
  width: 1360px;
  height: 650px;
  display: flex;
  border-radius: 15px;
}

.wrapper .wrapper_left {
  width: 280px;
  background: black;
  padding: 0 25px;
  display: flex;
  align-items: center;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
  box-shadow: 10px 0px 13px 0px rgba(41, 41, 57, 0.7);

}
.wrapper .wrapper_left ul li {
  background: #313142;
  margin-bottom: 25px;
  border-radius: 3px;
  padding: 12px 25px;
  text-transform: uppercase;
  font-weight: 500;
  position: relative;
  overflow: hidden;
  width: 220px;
  letter-spacing: 2px;
  transition: all 0.4s ease;
  cursor: pointer;
}

.wrapper .wrapper_left ul li p {
  color: #abaacd;
  position: relative;
}

.wrapper .wrapper_left ul li:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background: #5437b7;
  background: linear-gradient(
    126deg,
    rgba(2, 0, 36, 1) 0%,
    rgba(123, 90, 231, 1) 0%,
    rgba(88, 54, 206, 1) 100%
  );
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transition: all 0.4s ease;
}

.wrapper .wrapper_left ul li.active {
  width: 220px;
}
.wrapper .wrapper_left ul li.active p {
  color: #fff;
}
.wrapper .wrapper_left ul li.active:before {
  width: 100%;
  transition: all 0.2s ease;
}

.wrapper .wrapper_left ul li:last-child {
  margin-bottom: 0;
}

.wrapper .wrapper_right {
  width: 1000px;
  padding: 30px 50px;

}

.wrapper .wrapper_right .title {
  padding: 5px 0px 5px 0px; 
  font-size: 24px;
  text-align: center;
  font-weight: 700;
  background-color: black;
  color: white;
  margin-bottom: 20px;
  text-transform: uppercase;
  border:1px solid black;
  border-radius: 20px;

}

.wrapper .wrapper_right .item .item_info {
  display:inline;
  justify-content: space-around;
  align-items: left;
}
.wrapper .wrapper_right .item .item_info .img {
  width: 200px;
  height: 200px;
  background: #fff;
  border-radius: 50%;
  margin-bottom: 20px;
  position: relative;
}

.wrapper .wrapper_right .item .item_info .img:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: url("frames.png") no-repeat 0 0;
  width: 94px;
  height: 101px;
}

.wrapper .wrapper_right .item.angular .item_info .img:before {
  background-position: 0 0;
  width: 94px;
  height: 101px;
}
.wrapper .wrapper_right .item.nodejs .item_info .img:before {
  background-position: 0 -110px;
  width: 89px;
  height: 101px;
}
.wrapper .wrapper_right .item.reactjs .item_info .img:before {
  background-position: 0 -220px;
  width: 100px;
  height: 100px;
}
.wrapper .wrapper_right .item.vuejs .item_info .img:before {
  background-position: 0 -330px;
  width: 100px;
  height: 101px;
}

.wrapper .wrapper_right .item .item_info p {
  background: #fff;
  width: 300px;
  padding: 10px;
  border-radius: 5px;
  color: black;
  font-weight: 700;
  font-size: 20px;
  text-transform: uppercase;
  text-align: center;
}
.wrapper .wrapper_right .item.angular .item_info p {
  color: #dd0330;
}
.wrapper .wrapper_right .item.nodejs .item_info p {
  color: #8bc500;
}
.wrapper .wrapper_right .item.reactjs .item_info p {
  color: #61dafb;
}
.wrapper .wrapper_right .item.vuejs .item_info p {
  color: #41b783;
}

.wrapper .wrapper_right .item p {
  margin-bottom: 20px;
  color: #fff;
}
h2{
  color: white;
  text-align: center;
  padding-bottom: 40px;

}
.wrapper .wrapper_right .item .item_info .log{
  margin-top: 250px;
  margin-left: 20px;
  text-align: center;
  background-color: black;
  color: white;
  width: 600px

}
a{
  font-size: 20px;
  color:red;
  text-decoration: red;
}
a:hover{
  color: #606157;
}
</style>

</head>
<body>
<div class="wrapper">
  <div class="wrapper_left">

  <ul>
        <h2>WELCOME</h2>
      <li data-li="details">
        <p>Hospital Details</p>
      </li>
      <li data-li="doorders">
        <p>new order</p>
      </li>
      <li data-li="orders">
        <p>Applied Orders</p>
      </li>
      <li data-li="check">
        <p>check stock</p>
      </li>
      <li data-li="update">
        <p>update details</p>
      </li>
      <li data-li="change">
        <p>change password</p>
      </li>
      <li data-li="logout">
        <p>logout</p>
      </li>
    </ul>
  </div>
  <div class="wrapper_right">
    <div class="title">
	  Hospital management
    </div>
    <div class="container">
      <div class="item details" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Hospital Details</p>
          <?php include("hospital-details.php"); ?>
        </div>

	</div>
   <div class="item doorders" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Add orders</p>
          <?php include("hnew-order.php"); ?>
        </div>
   </div>
      <div class="item orders" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Orders Applied</p>
          <?php include("hospital-orders.php"); ?>
        </div>
     
	 </div>
    <div class="item check" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>find stock availability</p>
          <?php include("blood_availability.php"); ?>
        </div>
     
   </div>
      <div class="item update" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>Update details </p>
          <?php include("hupdate-details.php"); ?>
        </div>
      </div>
      <div class="item change" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p>change password</p>
          <?php include("hchange-password.php"); ?>
        </div>
      </div>
        <div class="item logout" style="display: none;">
        <div class="item_info">
          <div class=""></div>
          <p class="log">Do You Really Want to Logout?<br><a href="hospital.php">Click Here</a></p>
          <?php //include("logout.php"); ?>
        </div>
       </div>
		
		
       
  </div>
</div>
	<script>
var li_elements = document.querySelectorAll(".wrapper_left ul li");
var item_elements = document.querySelectorAll(".item");
for (var i = 0; i < li_elements.length; i++) {
  li_elements[i].addEventListener("click", function() {
    li_elements.forEach(function(li) {
      li.classList.remove("active");
    });
    this.classList.add("active");
    var li_value = this.getAttribute("data-li");
    item_elements.forEach(function(item) {
      item.style.display = "none";
    });
    if (li_value == "details") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "doorders") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "orders") {
      document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "check") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "update") {
      document.querySelector("." + li_value).style.display = "block";
    }else if (li_value == "change") {
    document.querySelector("." + li_value).style.display = "block";
    } else if (li_value == "logout") {
      document.querySelector("." + li_value).style.display = "block";
    }  else {
      console.log("");
    }
  });
}
	</script>
</body>
</html>